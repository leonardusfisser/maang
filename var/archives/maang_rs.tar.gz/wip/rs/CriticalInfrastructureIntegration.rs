// apps/lillpepe/src/main.rs - Integration example

use actix_web::{web, App, HttpServer, HttpResponse};
use infrastructure_jobs::{JobQueue, JobType};
use infrastructure_migrations::MigrationManager;
use infrastructure_sessions::{SessionManager, SessionConfig};
use std::sync::Arc;
use tokio::sync::RwLock;

// ============================================================================
// APPLICATION STATE
// ============================================================================

pub struct AppState {
    pub db: surrealdb::Surreal<surrealdb::engine::any::Any>,
    pub job_queue: Arc<RwLock<JobQueue>>,
    pub session_manager: Arc<RwLock<SessionManager>>,
}

// ============================================================================
// MAIN FUNCTION
// ============================================================================

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    // Initialize tracing
    tracing_subscriber::fmt::init();

    // Connect to SurrealDB
    let db = surrealdb::engine::any::connect("ws://localhost:8000")
        .await
        .expect("Failed to connect to SurrealDB");

    db.use_ns("lillpepe")
        .use_db("main")
        .await
        .expect("Failed to select namespace/database");

    // ========================================================================
    // INITIALIZE MIGRATIONS
    // ========================================================================

    tracing::info!("Running database migrations");
    let migration_manager = MigrationManager::new(db.clone(), "migrations".to_string());

    migration_manager
        .init()
        .await
        .expect("Failed to initialize migrations");

    let applied = migration_manager
        .run_pending()
        .await
        .expect("Failed to run migrations");

    if !applied.is_empty() {
        tracing::info!("Applied {} migrations", applied.len());
    }

    // ========================================================================
    // INITIALIZE JOB QUEUE
    // ========================================================================

    tracing::info!("Starting background job queue");
    let job_queue = Arc::new(RwLock::new(JobQueue::new(db.clone(), 4))); // 4 workers

    // Start job workers in background
    let job_queue_clone = Arc::clone(&job_queue);
    tokio::spawn(async move {
        let queue = job_queue_clone.read().await;
        queue.start().await;
    });

    // ========================================================================
    // INITIALIZE SESSION MANAGER
    // ========================================================================

    tracing::info!("Initializing session management");
    let session_config = SessionConfig::production();
    let session_manager = SessionManager::new(&session_config.redis_url, session_config.ttl_seconds)
        .await
        .expect("Failed to connect to Redis");

    let session_manager = Arc::new(RwLock::new(session_manager));

    // ========================================================================
    // CREATE APPLICATION STATE
    // ========================================================================

    let app_state = web::Data::new(AppState {
        db: db.clone(),
        job_queue: Arc::clone(&job_queue),
        session_manager: Arc::clone(&session_manager),
    });

    // ========================================================================
    // START HTTP SERVER
    // ========================================================================

    tracing::info!("Starting HTTP server on 0.0.0.0:8080");

    HttpServer::new(move || {
        App::new()
            .app_data(app_state.clone())
            .configure(configure_routes)
    })
        .bind(("0.0.0.0", 8080))?
        .run()
        .await
}

// ============================================================================
// ROUTE CONFIGURATION
// ============================================================================

fn configure_routes(cfg: &mut web::ServiceConfig) {
    cfg.service(
        web::scope("/api/v1")
            .route("/health", web::get().to(health_check))
            .route("/auth/login", web::post().to(login))
            .route("/auth/logout", web::post().to(logout))
            .route("/jobs/stats", web::get().to(job_stats))
    );
}

// ============================================================================
// HANDLERS
// ============================================================================

async fn health_check(state: web::Data<AppState>) -> HttpResponse {
    // Check job queue stats
    let job_queue = state.job_queue.read().await;
    let stats = job_queue.get_stats().await.unwrap_or_else(|_| {
        infrastructure_jobs::JobStats {
            pending: 0,
            running: 0,
            failed: 0,
        }
    });

    // Check active sessions
    let session_manager = state.session_manager.read().await;
    let sessions = session_manager.get_active_sessions().await.ok();

    HttpResponse::Ok().json(serde_json::json!({
        "status": "healthy",
        "jobs": {
            "pending": stats.pending,
            "running": stats.running,
            "failed": stats.failed,
        },
        "sessions": {
            "active": sessions.as_ref().map(|s| s.len()).unwrap_or(0),
        }
    }))
}

async fn login(
    state: web::Data<AppState>,
    body: web::Json<LoginRequest>,
) -> HttpResponse {
    // Validate credentials (placeholder)
    let user_id = "user_123".to_string();
    let email = body.email.clone();

    // Create session
    let mut session_manager = state.session_manager.write().await;
    let session_id = session_manager
        .create_session(
            user_id.clone(),
            None,
            email.clone(),
            infrastructure_sessions::UserRole::User,
            "127.0.0.1".to_string(),
            "Mozilla/5.0".to_string(),
        )
        .await
        .expect("Failed to create session");

    // Enqueue welcome email job
    let mut job_queue = state.job_queue.write().await;
    let _job_id = job_queue
        .enqueue(
            JobType::SendWelcomeEmail {
                user_id: user_id.clone(),
                email: email.clone(),
            },
            10, // priority
        )
        .await
        .expect("Failed to enqueue job");

    HttpResponse::Ok().json(serde_json::json!({
        "session_id": session_id,
        "user_id": user_id,
        "email": email,
    }))
}

async fn logout(
    state: web::Data<AppState>,
    body: web::Json<LogoutRequest>,
) -> HttpResponse {
    let mut session_manager = state.session_manager.write().await;

    match session_manager.destroy_session(&body.session_id).await {
        Ok(_) => HttpResponse::Ok().json(serde_json::json!({
            "message": "Logged out successfully"
        })),
        Err(_) => HttpResponse::BadRequest().json(serde_json::json!({
            "error": "Invalid session"
        })),
    }
}

async fn job_stats(state: web::Data<AppState>) -> HttpResponse {
    let job_queue = state.job_queue.read().await;

    match job_queue.get_stats().await {
        Ok(stats) => HttpResponse::Ok().json(stats),
        Err(e) => HttpResponse::InternalServerError().json(serde_json::json!({
            "error": e.to_string()
        })),
    }
}

// ============================================================================
// REQUEST/RESPONSE TYPES
// ============================================================================

#[derive(serde::Deserialize)]
struct LoginRequest {
    email: String,
    password: String,
}

#[derive(serde::Deserialize)]
struct LogoutRequest {
    session_id: String,
}

// ============================================================================
// EXAMPLE: ENQUEUEING JOBS FROM STRIPE WEBHOOK
// ============================================================================

async fn stripe_webhook_handler(
    state: web::Data<AppState>,
    body: web::Json<StripeWebhookPayload>,
) -> HttpResponse {
    let mut job_queue = state.job_queue.write().await;

    // Enqueue job to process webhook asynchronously
    match job_queue
        .enqueue(
            JobType::ProcessStripeWebhook {
                event_id: body.id.clone(),
                event_type: body.event_type.clone(),
            },
            100, // High priority
        )
        .await
    {
        Ok(job_id) => {
            tracing::info!("Enqueued Stripe webhook job: {}", job_id);
            HttpResponse::Ok().json(serde_json::json!({
                "received": true,
                "job_id": job_id,
            }))
        }
        Err(e) => {
            tracing::error!("Failed to enqueue webhook job: {}", e);
            HttpResponse::InternalServerError().json(serde_json::json!({
                "error": "Failed to process webhook"
            }))
        }
    }
}

#[derive(serde::Deserialize)]
struct StripeWebhookPayload {
    id: String,
    #[serde(rename = "type")]
    event_type: String,
}

// ============================================================================
// EXAMPLE: SCHEDULED JOBS (CRON)
// ============================================================================

async fn schedule_maintenance_jobs(job_queue: Arc<RwLock<JobQueue>>) {
    loop {
        tokio::time::sleep(tokio::time::Duration::from_secs(3600)).await; // Every hour

        let mut queue = job_queue.write().await;

        // Cleanup expired sessions
        let _ = queue
            .enqueue(JobType::CleanupExpiredSessions, 1)
            .await;

        // Rotate logs
        let _ = queue
            .enqueue(JobType::RotateLogs, 1)
            .await;

        tracing::info!("Scheduled maintenance jobs");
    }
}