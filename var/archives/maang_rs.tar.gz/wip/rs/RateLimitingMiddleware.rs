// crates/infrastructure/ratelimit/src/lib.rs
//! Redis-backed rate limiting with per-tenant quotas

use actix_web::{
    dev::{forward_ready, Service, ServiceRequest, ServiceResponse, Transform},
    Error, HttpResponse,
};
use futures_util::future::LocalBoxFuture;
use redis::aio::MultiplexedConnection;
use redis::AsyncCommands;
use std::future::{ready, Ready};
use std::rc::Rc;
use std::time::Duration;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum RateLimitError {
    #[error("Redis error: {0}")]
    RedisError(String),

    #[error("Rate limit exceeded")]
    LimitExceeded,
}

// ============================================================================
// RATE LIMIT CONFIGURATION
// ============================================================================

#[derive(Debug, Clone)]
pub struct RateLimitConfig {
    pub requests_per_window: u32,
    pub window_seconds: u64,
    pub burst_size: u32,
}

impl RateLimitConfig {
    pub fn global() -> Self {
        Self {
            requests_per_window: 100,
            window_seconds: 60,
            burst_size: 10,
        }
    }

    pub fn per_tenant() -> Self {
        Self {
            requests_per_window: 1000,
            window_seconds: 60,
            burst_size: 50,
        }
    }

    pub fn api() -> Self {
        Self {
            requests_per_window: 60,
            window_seconds: 60,
            burst_size: 10,
        }
    }

    pub fn auth() -> Self {
        Self {
            requests_per_window: 5,
            window_seconds: 300, // 5 minutes
            burst_size: 2,
        }
    }
}

// ============================================================================
// RATE LIMITER
// ============================================================================

pub struct RateLimiter {
    redis: MultiplexedConnection,
}

impl RateLimiter {
    pub async fn new(redis_url: &str) -> Result<Self, RateLimitError> {
        let client = redis::Client::open(redis_url)
            .map_err(|e| RateLimitError::RedisError(e.to_string()))?;

        let redis = client
            .get_multiplexed_async_connection()
            .await
            .map_err(|e| RateLimitError::RedisError(e.to_string()))?;

        Ok(Self { redis })
    }

    pub async fn check_limit(
        &mut self,
        key: &str,
        config: &RateLimitConfig,
    ) -> Result<RateLimitInfo, RateLimitError> {
        let now = chrono::Utc::now().timestamp();
        let window_start = now - (now % config.window_seconds as i64);
        let rate_key = format!("ratelimit:{}:{}", key, window_start);

        // Increment counter
        let count: u32 = self.redis
            .incr(&rate_key, 1)
            .await
            .map_err(|e| RateLimitError::RedisError(e.to_string()))?;

        // Set expiry on first request in window
        if count == 1 {
            self.redis
                .expire(&rate_key, config.window_seconds as i64 + 10)
                .await
                .map_err(|e| RateLimitError::RedisError(e.to_string()))?;
        }

        let remaining = if count <= config.requests_per_window {
            config.requests_per_window - count
        } else {
            0
        };

        let reset_at = window_start + config.window_seconds as i64;

        if count > config.requests_per_window {
            Err(RateLimitError::LimitExceeded)
        } else {
            Ok(RateLimitInfo {
                limit: config.requests_per_window,
                remaining,
                reset_at,
            })
        }
    }

    pub async fn reset(&mut self, key: &str) -> Result<(), RateLimitError> {
        let pattern = format!("ratelimit:{}:*", key);

        let keys: Vec<String> = self.redis
            .keys(&pattern)
            .await
            .map_err(|e| RateLimitError::RedisError(e.to_string()))?;

        for key in keys {
            self.redis
                .del(&key)
                .await
                .map_err(|e| RateLimitError::RedisError(e.to_string()))?;
        }

        Ok(())
    }
}

#[derive(Debug, Clone)]
pub struct RateLimitInfo {
    pub limit: u32,
    pub remaining: u32,
    pub reset_at: i64,
}

// ============================================================================
// ACTIX-WEB MIDDLEWARE
// ============================================================================

pub struct RateLimitMiddleware {
    config: RateLimitConfig,
    redis_url: String,
}

impl RateLimitMiddleware {
    pub fn new(config: RateLimitConfig, redis_url: String) -> Self {
        Self { config, redis_url }
    }
}

impl<S, B> Transform<S, ServiceRequest> for RateLimitMiddleware
where
    S: Service<ServiceRequest, Response = ServiceResponse<B>, Error = Error> + 'static,
    S::Future: 'static,
    B: 'static,
{
    type Response = ServiceResponse<B>;
    type Error = Error;
    type InitError = ();
    type Transform = RateLimitMiddlewareService<S>;
    type Future = Ready<Result<Self::Transform, Self::InitError>>;

    fn new_transform(&self, service: S) -> Self::Future {
        ready(Ok(RateLimitMiddlewareService {
            service: Rc::new(service),
            config: self.config.clone(),
            redis_url: self.redis_url.clone(),
        }))
    }
}

pub struct RateLimitMiddlewareService<S> {
    service: Rc<S>,
    config: RateLimitConfig,
    redis_url: String,
}

impl<S, B> Service<ServiceRequest> for RateLimitMiddlewareService<S>
where
    S: Service<ServiceRequest, Response = ServiceResponse<B>, Error = Error> + 'static,
    S::Future: 'static,
    B: 'static,
{
    type Response = ServiceResponse<B>;
    type Error = Error;
    type Future = LocalBoxFuture<'static, Result<Self::Response, Self::Error>>;

    forward_ready!(service);

    fn call(&self, req: ServiceRequest) -> Self::Future {
        let service = Rc::clone(&self.service);
        let config = self.config.clone();
        let redis_url = self.redis_url.clone();

        Box::pin(async move {
            // Extract identifier (IP address or tenant ID)
            let identifier = if let Some(tenant_id) = req.headers().get("X-Tenant-ID") {
                format!("tenant:{}", tenant_id.to_str().unwrap_or("unknown"))
            } else {
                let ip = req
                    .connection_info()
                    .peer_addr()
                    .unwrap_or("unknown")
                    .to_string();
                format!("ip:{}", ip)
            };

            // Check rate limit
            let mut limiter = RateLimiter::new(&redis_url)
                .await
                .map_err(actix_web::error::ErrorInternalServerError)?;

            match limiter.check_limit(&identifier, &config).await {
                Ok(info) => {
                    // Add rate limit headers
                    let res = service.call(req).await?;

                    Ok(res.map_into_right_body().map_into_boxed_body())
                }
                Err(RateLimitError::LimitExceeded) => {
                    let retry_after = config.window_seconds;

                    Err(actix_web::error::ErrorTooManyRequests(
                        HttpResponse::TooManyRequests()
                            .insert_header(("X-RateLimit-Limit", config.requests_per_window.to_string()))
                            .insert_header(("X-RateLimit-Remaining", "0"))
                            .insert_header(("Retry-After", retry_after.to_string()))
                            .json(serde_json::json!({
                                "error": "Rate limit exceeded",
                                "retry_after": retry_after,
                            }))
                    ))
                }
                Err(e) => {
                    tracing::error!("Rate limit check failed: {}", e);
                    // Allow request on error (fail open)
                    service.call(req).await
                }
            }
        })
    }
}

// ============================================================================
// CONVENIENCE FUNCTIONS
// ============================================================================

pub fn global_rate_limit(redis_url: String) -> RateLimitMiddleware {
    RateLimitMiddleware::new(RateLimitConfig::global(), redis_url)
}

pub fn tenant_rate_limit(redis_url: String) -> RateLimitMiddleware {
    RateLimitMiddleware::new(RateLimitConfig::per_tenant(), redis_url)
}

pub fn api_rate_limit(redis_url: String) -> RateLimitMiddleware {
    RateLimitMiddleware::new(RateLimitConfig::api(), redis_url)
}

pub fn auth_rate_limit(redis_url: String) -> RateLimitMiddleware {
    RateLimitMiddleware::new(RateLimitConfig::auth(), redis_url)
}