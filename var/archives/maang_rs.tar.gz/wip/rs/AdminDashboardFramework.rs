// apps/lillpepe/src/admin/mod.rs
//! Admin dashboard routes and handlers

use actix_web::{web, HttpRequest, HttpResponse};
use askama::Template;
use infrastructure_audit::AuditLogger;
use infrastructure_jobs::JobQueue;
use infrastructure_sessions::SessionManager;
use serde::{Deserialize, Serialize};
use tokio::sync::RwLock;
use std::sync::Arc;

// ============================================================================
// ADMIN STATE
// ============================================================================

pub struct AdminState {
    pub db: surrealdb::Surreal<surrealdb::engine::any::Any>,
    pub job_queue: Arc<RwLock<JobQueue>>,
    pub session_manager: Arc<RwLock<SessionManager>>,
    pub audit_logger: Arc<AuditLogger>,
}

// ============================================================================
// DASHBOARD TEMPLATES
// ============================================================================

#[derive(Template)]
#[template(path = "admin/dashboard.html")]
pub struct DashboardTemplate {
    pub stats: DashboardStats,
    pub recent_tenants: Vec<TenantSummary>,
    pub recent_activity: Vec<ActivityItem>,
}

#[derive(Template)]
#[template(path = "admin/tenants.html")]
pub struct TenantsTemplate {
    pub tenants: Vec<TenantDetail>,
    pub total: usize,
    pub page: usize,
}

#[derive(Template)]
#[template(path = "admin/tenant_detail.html")]
pub struct TenantDetailTemplate {
    pub tenant: TenantDetail,
    pub usage: UsageStats,
    pub activity: Vec<ActivityItem>,
}

#[derive(Template)]
#[template(path = "admin/jobs.html")]
pub struct JobsTemplate {
    pub stats: JobStats,
    pub failed_jobs: Vec<JobDetail>,
}

#[derive(Template)]
#[template(path = "admin/audit.html")]
pub struct AuditTemplate {
    pub logs: Vec<AuditLogItem>,
    pub total: usize,
}

// ============================================================================
// DATA STRUCTURES
// ============================================================================

#[derive(Debug, Serialize, Deserialize)]
pub struct DashboardStats {
    pub total_tenants: usize,
    pub active_tenants: usize,
    pub total_revenue: f64,
    pub mrr: f64,
    pub pending_jobs: usize,
    pub failed_jobs: usize,
    pub active_sessions: usize,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct TenantSummary {
    pub id: String,
    pub name: String,
    pub domain: String,
    pub plan: String,
    pub status: String,
    pub created_at: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct TenantDetail {
    pub id: String,
    pub name: String,
    pub domain: String,
    pub subdomain: String,
    pub plan: String,
    pub status: String,
    pub owner_email: String,
    pub created_at: String,
    pub last_login: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ActivityItem {
    pub timestamp: String,
    pub user: String,
    pub action: String,
    pub resource: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct JobStats {
    pub pending: usize,
    pub running: usize,
    pub completed: usize,
    pub failed: usize,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct JobDetail {
    pub id: String,
    pub job_type: String,
    pub attempts: u32,
    pub error: Option<String>,
    pub created_at: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct UsageStats {
    pub products: usize,
    pub services: usize,
    pub media_files: usize,
    pub storage_mb: f64,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct AuditLogItem {
    pub timestamp: String,
    pub user: String,
    pub action: String,
    pub resource: String,
    pub ip_address: String,
}

// ============================================================================
// ROUTE HANDLERS
// ============================================================================

pub async fn dashboard(state: web::Data<AdminState>) -> HttpResponse {
    // Fetch dashboard stats
    let stats = fetch_dashboard_stats(&state).await;
    let recent_tenants = fetch_recent_tenants(&state, 5).await;
    let recent_activity = fetch_recent_activity(&state, 10).await;

    let template = DashboardTemplate {
        stats,
        recent_tenants,
        recent_activity,
    };

    HttpResponse::Ok()
        .content_type("text/html")
        .body(template.render().unwrap_or_else(|_| "Error rendering template".to_string()))
}

pub async fn tenants_list(
    state: web::Data<AdminState>,
    query: web::Query<PaginationParams>,
) -> HttpResponse {
    let tenants = fetch_tenants(&state, query.page.unwrap_or(1), 20).await;
    let total = count_tenants(&state).await;

    let template = TenantsTemplate {
        tenants,
        total,
        page: query.page.unwrap_or(1),
    };

    HttpResponse::Ok()
        .content_type("text/html")
        .body(template.render().unwrap_or_else(|_| "Error rendering template".to_string()))
}

pub async fn tenant_detail(
    state: web::Data<AdminState>,
    path: web::Path<String>,
) -> HttpResponse {
    let tenant_id = path.into_inner();

    let tenant = fetch_tenant_detail(&state, &tenant_id).await;
    let usage = fetch_tenant_usage(&state, &tenant_id).await;
    let activity = fetch_tenant_activity(&state, &tenant_id, 20).await;

    let template = TenantDetailTemplate {
        tenant,
        usage,
        activity,
    };

    HttpResponse::Ok()
        .content_type("text/html")
        .body(template.render().unwrap_or_else(|_| "Error rendering template".to_string()))
}

pub async fn jobs_dashboard(state: web::Data<AdminState>) -> HttpResponse {
    let job_queue = state.job_queue.read().await;
    let stats = job_queue.get_stats().await.unwrap_or_else(|_| infrastructure_jobs::JobStats {
        pending: 0,
        running: 0,
        failed: 0,
    });

    let job_stats = JobStats {
        pending: stats.pending,
        running: stats.running,
        completed: 0,
        failed: stats.failed,
    };

    let failed_jobs = fetch_failed_jobs(&state, 20).await;

    let template = JobsTemplate {
        stats: job_stats,
        failed_jobs,
    };

    HttpResponse::Ok()
        .content_type("text/html")
        .body(template.render().unwrap_or_else(|_| "Error rendering template".to_string()))
}

pub async fn audit_logs(
    state: web::Data<AdminState>,
    query: web::Query<AuditQueryParams>,
) -> HttpResponse {
    let logs = fetch_audit_logs(&state, &query).await;
    let total = logs.len();

    let template = AuditTemplate {
        logs,
        total,
    };

    HttpResponse::Ok()
        .content_type("text/html")
        .body(template.render().unwrap_or_else(|_| "Error rendering template".to_string()))
}

// ============================================================================
// API ENDPOINTS
// ============================================================================

pub async fn api_suspend_tenant(
    state: web::Data<AdminState>,
    path: web::Path<String>,
) -> HttpResponse {
    let tenant_id = path.into_inner();

    // Update tenant status
    let result: Result<Option<serde_json::Value>, _> = state.db
        .query(&format!(
            "UPDATE white_labels:{} SET status = 'suspended'",
            tenant_id
        ))
        .await;

    match result {
        Ok(_) => HttpResponse::Ok().json(serde_json::json!({
            "success": true,
            "message": "Tenant suspended"
        })),
        Err(e) => HttpResponse::InternalServerError().json(serde_json::json!({
            "error": e.to_string()
        })),
    }
}

pub async fn api_activate_tenant(
    state: web::Data<AdminState>,
    path: web::Path<String>,
) -> HttpResponse {
    let tenant_id = path.into_inner();

    let result: Result<Option<serde_json::Value>, _> = state.db
        .query(&format!(
            "UPDATE white_labels:{} SET status = 'active'",
            tenant_id
        ))
        .await;

    match result {
        Ok(_) => HttpResponse::Ok().json(serde_json::json!({
            "success": true,
            "message": "Tenant activated"
        })),
        Err(e) => HttpResponse::InternalServerError().json(serde_json::json!({
            "error": e.to_string()
        })),
    }
}

pub async fn api_delete_tenant(
    state: web::Data<AdminState>,
    path: web::Path<String>,
) -> HttpResponse {
    let tenant_id = path.into_inner();

    // Enqueue deletion job
    let mut queue = state.job_queue.write().await;
    let result = queue
        .enqueue(
            infrastructure_jobs::JobType::DeleteTenant {
                tenant_id: tenant_id.clone(),
            },
            100,
        )
        .await;

    match result {
        Ok(job_id) => HttpResponse::Ok().json(serde_json::json!({
            "success": true,
            "message": "Tenant deletion queued",
            "job_id": job_id
        })),
        Err(e) => HttpResponse::InternalServerError().json(serde_json::json!({
            "error": e.to_string()
        })),
    }
}

pub async fn api_retry_job(
    state: web::Data<AdminState>,
    path: web::Path<String>,
) -> HttpResponse {
    let job_id = path.into_inner();

    // Reset job status to pending
    let result: Result<Option<serde_json::Value>, _> = state.db
        .query(&format!(
            "UPDATE jobs:{} SET status = 'pending', attempts = 0",
            job_id
        ))
        .await;

    match result {
        Ok(_) => HttpResponse::Ok().json(serde_json::json!({
            "success": true,
            "message": "Job queued for retry"
        })),
        Err(e) => HttpResponse::InternalServerError().json(serde_json::json!({
            "error": e.to_string()
        })),
    }
}

// ============================================================================
// DATA FETCHERS
// ============================================================================

async fn fetch_dashboard_stats(state: &AdminState) -> DashboardStats {
    // TODO: Implement actual queries
    DashboardStats {
        total_tenants: 42,
        active_tenants: 38,
        total_revenue: 5420.0,
        mrr: 2100.0,
        pending_jobs: 5,
        failed_jobs: 2,
        active_sessions: 12,
    }
}

async fn fetch_recent_tenants(state: &AdminState, limit: usize) -> Vec<TenantSummary> {
    // TODO: Implement actual query
    vec![]
}

async fn fetch_recent_activity(state: &AdminState, limit: usize) -> Vec<ActivityItem> {
    // TODO: Implement actual query
    vec![]
}

async fn fetch_tenants(state: &AdminState, page: usize, per_page: usize) -> Vec<TenantDetail> {
    // TODO: Implement actual query
    vec![]
}

async fn count_tenants(state: &AdminState) -> usize {
    // TODO: Implement actual query
    0
}

async fn fetch_tenant_detail(state: &AdminState, tenant_id: &str) -> TenantDetail {
    // TODO: Implement actual query
    TenantDetail {
        id: tenant_id.to_string(),
        name: "Example Tenant".to_string(),
        domain: "example.com".to_string(),
        subdomain: "example".to_string(),
        plan: "pro".to_string(),
        status: "active".to_string(),
        owner_email: "owner@example.com".to_string(),
        created_at: chrono::Utc::now().to_rfc3339(),
        last_login: None,
    }
}

async fn fetch_tenant_usage(state: &AdminState, tenant_id: &str) -> UsageStats {
    // TODO: Implement actual query
    UsageStats {
        products: 12,
        services: 5,
        media_files: 34,
        storage_mb: 156.7,
    }
}

async fn fetch_tenant_activity(
    state: &AdminState,
    tenant_id: &str,
    limit: usize,
) -> Vec<ActivityItem> {
    // TODO: Implement actual query
    vec![]
}

async fn fetch_failed_jobs(state: &AdminState, limit: usize) -> Vec<JobDetail> {
    // TODO: Implement actual query
    vec![]
}

async fn fetch_audit_logs(state: &AdminState, query: &AuditQueryParams) -> Vec<AuditLogItem> {
    // TODO: Implement actual query
    vec![]
}

// ============================================================================
// QUERY PARAMS
// ============================================================================

#[derive(Debug, Deserialize)]
pub struct PaginationParams {
    pub page: Option<usize>,
}

#[derive(Debug, Deserialize)]
pub struct AuditQueryParams {
    pub user_id: Option<String>,
    pub tenant_id: Option<String>,
    pub start_date: Option<String>,
    pub end_date: Option<String>,
}

// ============================================================================
// ROUTE CONFIGURATION
// ============================================================================

pub fn configure_admin_routes(cfg: &mut web::ServiceConfig) {
    cfg.service(
        web::scope("/admin")
            .route("", web::get().to(dashboard))
            .route("/tenants", web::get().to(tenants_list))
            .route("/tenants/{id}", web::get().to(tenant_detail))
            .route("/jobs", web::get().to(jobs_dashboard))
            .route("/audit", web::get().to(audit_logs))
            // API endpoints
            .route("/api/tenants/{id}/suspend", web::post().to(api_suspend_tenant))
            .route("/api/tenants/{id}/activate", web::post().to(api_activate_tenant))
            .route("/api/tenants/{id}/delete", web::delete().to(api_delete_tenant))
            .route("/api/jobs/{id}/retry", web::post().to(api_retry_job))
    );
}