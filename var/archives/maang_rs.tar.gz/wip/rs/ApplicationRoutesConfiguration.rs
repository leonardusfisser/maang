// apps/lillpepe/src/routes.rs
//! Application route configuration

use actix_web::{web, HttpResponse};
use crate::AppState;

// ============================================================================
// PUBLIC ROUTES
// ============================================================================

pub fn configure_public_routes(cfg: &mut web::ServiceConfig) {
    cfg.service(
        web::scope("")
            .route("/", web::get().to(home))
            .route("/about", web::get().to(about))
            .route("/pricing", web::get().to(pricing))
            .route("/contact", web::get().to(contact))
    );
}

async fn home() -> HttpResponse {
    HttpResponse::Ok().body("Welcome to Lillpepe")
}

async fn about() -> HttpResponse {
    HttpResponse::Ok().body("About Lillpepe")
}

async fn pricing() -> HttpResponse {
    HttpResponse::Ok().body("Pricing")
}

async fn contact() -> HttpResponse {
    HttpResponse::Ok().body("Contact Us")
}

// ============================================================================
// API ROUTES
// ============================================================================

pub fn configure_api_routes(cfg: &mut web::ServiceConfig) {
    cfg.service(
        web::scope("/api/v1")
            // Health check
            .route("/health", web::get().to(health_check))

            // Authentication
            .route("/auth/register", web::post().to(register))
            .route("/auth/login", web::post().to(login))
            .route("/auth/logout", web::post().to(logout))
            .route("/auth/password-reset", web::post().to(password_reset))

            // Onboarding
            .route("/onboarding/start", web::post().to(start_onboarding))
            .route("/onboarding/verify-email", web::post().to(verify_email))
            .route("/onboarding/select-plan", web::post().to(select_plan))
            .route("/onboarding/setup-payment", web::post().to(setup_payment))
            .route("/onboarding/select-domain", web::post().to(select_domain))
            .route("/onboarding/complete-setup", web::post().to(complete_setup))

            // Tenants
            .route("/tenants", web::get().to(list_tenants))
            .route("/tenants/{id}", web::get().to(get_tenant))
            .route("/tenants/{id}", web::put().to(update_tenant))

            // Products
            .route("/products", web::get().to(list_products))
            .route("/products", web::post().to(create_product))
            .route("/products/{id}", web::get().to(get_product))
            .route("/products/{id}", web::put().to(update_product))
            .route("/products/{id}", web::delete().to(delete_product))

            // Services
            .route("/services", web::get().to(list_services))
            .route("/services", web::post().to(create_service))
            .route("/services/{id}", web::get().to(get_service))
            .route("/services/{id}", web::put().to(update_service))
            .route("/services/{id}", web::delete().to(delete_service))

            // Media
            .route("/media", web::get().to(list_media))
            .route("/media/upload", web::post().to(upload_media))
            .route("/media/{id}", web::delete().to(delete_media))

            // Webhooks
            .route("/webhooks/stripe", web::post().to(stripe_webhook))
    );
}

// ============================================================================
// HEALTH CHECK
// ============================================================================

async fn health_check(state: web::Data<AppState>) -> HttpResponse {
    let job_queue = state.job_queue.read().await;
    let stats = job_queue.get_stats().await.unwrap_or_else(|_| {
        infrastructure_jobs::JobStats {
            pending: 0,
            running: 0,
            failed: 0,
        }
    });

    let session_manager = state.session_manager.read().await;
    let sessions = session_manager.get_active_sessions().await.ok();

    HttpResponse::Ok().json(serde_json::json!({
        "status": "healthy",
        "timestamp": chrono::Utc::now().to_rfc3339(),
        "version": env!("CARGO_PKG_VERSION"),
        "jobs": {
            "pending": stats.pending,
            "running": stats.running,
            "failed": stats.failed,
        },
        "sessions": {
            "active": sessions.as_ref().map(|s| s.len()).unwrap_or(0),
        }
    }))
}

// ============================================================================
// AUTHENTICATION
// ============================================================================

use serde::Deserialize;

#[derive(Deserialize)]
struct RegisterRequest {
    email: String,
    password: String,
    name: String,
}

async fn register(
    state: web::Data<AppState>,
    body: web::Json<RegisterRequest>,
) -> HttpResponse {
    // TODO: Implement registration
    HttpResponse::Ok().json(serde_json::json!({
        "message": "Registration successful"
    }))
}

#[derive(Deserialize)]
struct LoginRequest {
    email: String,
    password: String,
}

async fn login(
    state: web::Data<AppState>,
    body: web::Json<LoginRequest>,
) -> HttpResponse {
    // TODO: Implement login
    HttpResponse::Ok().json(serde_json::json!({
        "message": "Login successful",
        "session_id": "placeholder"
    }))
}

async fn logout(state: web::Data<AppState>) -> HttpResponse {
    HttpResponse::Ok().json(serde_json::json!({
        "message": "Logged out successfully"
    }))
}

#[derive(Deserialize)]
struct PasswordResetRequest {
    email: String,
}

async fn password_reset(
    state: web::Data<AppState>,
    body: web::Json<PasswordResetRequest>,
) -> HttpResponse {
    // Enqueue password reset email
    let mut queue = state.job_queue.write().await;
    let _ = queue
        .enqueue(
            infrastructure_jobs::JobType::SendPasswordReset {
                user_id: "placeholder".to_string(),
                token: uuid::Uuid::new_v4().to_string(),
            },
            10,
        )
        .await;

    HttpResponse::Ok().json(serde_json::json!({
        "message": "Password reset email sent"
    }))
}

// ============================================================================
// ONBOARDING
// ============================================================================

#[derive(Deserialize)]
struct StartOnboardingRequest {
    email: String,
    name: String,
}

async fn start_onboarding(
    state: web::Data<AppState>,
    body: web::Json<StartOnboardingRequest>,
) -> HttpResponse {
    match state
        .onboarding_service
        .start_onboarding(body.email.clone(), body.name.clone())
        .await
    {
        Ok(user_id) => HttpResponse::Ok().json(serde_json::json!({
            "user_id": user_id,
            "next_step": "email_verification"
        })),
        Err(e) => HttpResponse::BadRequest().json(serde_json::json!({
            "error": e.to_string()
        })),
    }
}

#[derive(Deserialize)]
struct VerifyEmailRequest {
    user_id: String,
    token: String,
}

async fn verify_email(
    state: web::Data<AppState>,
    body: web::Json<VerifyEmailRequest>,
) -> HttpResponse {
    match state
        .onboarding_service
        .verify_email(&body.user_id)
        .await
    {
        Ok(_) => HttpResponse::Ok().json(serde_json::json!({
            "next_step": "plan_selection"
        })),
        Err(e) => HttpResponse::BadRequest().json(serde_json::json!({
            "error": e.to_string()
        })),
    }
}

#[derive(Deserialize)]
struct SelectPlanRequest {
    user_id: String,
    plan: String,
}

async fn select_plan(
    state: web::Data<AppState>,
    body: web::Json<SelectPlanRequest>,
) -> HttpResponse {
    match state
        .onboarding_service
        .select_plan(&body.user_id, body.plan.clone())
        .await
    {
        Ok(_) => HttpResponse::Ok().json(serde_json::json!({
            "next_step": "payment_setup"
        })),
        Err(e) => HttpResponse::BadRequest().json(serde_json::json!({
            "error": e.to_string()
        })),
    }
}

#[derive(Deserialize)]
struct SetupPaymentRequest {
    user_id: String,
    payment_method_id: String,
}

async fn setup_payment(
    state: web::Data<AppState>,
    body: web::Json<SetupPaymentRequest>,
) -> HttpResponse {
    match state
        .onboarding_service
        .setup_payment(&body.user_id, body.payment_method_id.clone())
        .await
    {
        Ok(_) => HttpResponse::Ok().json(serde_json::json!({
            "next_step": "domain_selection"
        })),
        Err(e) => HttpResponse::BadRequest().json(serde_json::json!({
            "error": e.to_string()
        })),
    }
}

#[derive(Deserialize)]
struct SelectDomainRequest {
    user_id: String,
    subdomain: String,
    custom_domain: Option<String>,
}

async fn select_domain(
    state: web::Data<AppState>,
    body: web::Json<SelectDomainRequest>,
) -> HttpResponse {
    match state
        .onboarding_service
        .select_domain(&body.user_id, body.subdomain.clone(), body.custom_domain.clone())
        .await
    {
        Ok(_) => HttpResponse::Ok().json(serde_json::json!({
            "next_step": "initial_setup",
            "message": "Tenant provisioning in progress"
        })),
        Err(e) => HttpResponse::BadRequest().json(serde_json::json!({
            "error": e.to_string()
        })),
    }
}

#[derive(Deserialize)]
struct CompleteSetupRequest {
    user_id: String,
    colors: Vec<String>,
}

async fn complete_setup(
    state: web::Data<AppState>,
    body: web::Json<CompleteSetupRequest>,
) -> HttpResponse {
    match state
        .onboarding_service
        .complete_initial_setup(&body.user_id, body.colors.clone())
        .await
    {
        Ok(_) => HttpResponse::Ok().json(serde_json::json!({
            "message": "Onboarding complete!",
            "redirect": "/dashboard"
        })),
        Err(e) => HttpResponse::BadRequest().json(serde_json::json!({
            "error": e.to_string()
        })),
    }
}

// ============================================================================
// PLACEHOLDER HANDLERS
// ============================================================================

async fn list_tenants() -> HttpResponse {
    HttpResponse::Ok().json(serde_json::json!({ "tenants": [] }))
}

async fn get_tenant(path: web::Path<String>) -> HttpResponse {
    HttpResponse::Ok().json(serde_json::json!({ "id": path.into_inner() }))
}

async fn update_tenant() -> HttpResponse {
    HttpResponse::Ok().json(serde_json::json!({ "message": "Updated" }))
}

async fn list_products() -> HttpResponse {
    HttpResponse::Ok().json(serde_json::json!({ "products": [] }))
}

async fn create_product() -> HttpResponse {
    HttpResponse::Created().json(serde_json::json!({ "message": "Created" }))
}

async fn get_product(path: web::Path<String>) -> HttpResponse {
    HttpResponse::Ok().json(serde_json::json!({ "id": path.into_inner() }))
}

async fn update_product() -> HttpResponse {
    HttpResponse::Ok().json(serde_json::json!({ "message": "Updated" }))
}

async fn delete_product() -> HttpResponse {
    HttpResponse::NoContent().finish()
}

async fn list_services() -> HttpResponse {
    HttpResponse::Ok().json(serde_json::json!({ "services": [] }))
}

async fn create_service() -> HttpResponse {
    HttpResponse::Created().json(serde_json::json!({ "message": "Created" }))
}

async fn get_service(path: web::Path<String>) -> HttpResponse {
    HttpResponse::Ok().json(serde_json::json!({ "id": path.into_inner() }))
}

async fn update_service() -> HttpResponse {
    HttpResponse::Ok().json(serde_json::json!({ "message": "Updated" }))
}

async fn delete_service() -> HttpResponse {
    HttpResponse::NoContent().finish()
}

async fn list_media() -> HttpResponse {
    HttpResponse::Ok().json(serde_json::json!({ "media": [] }))
}

async fn upload_media() -> HttpResponse {
    HttpResponse::Created().json(serde_json::json!({ "message": "Uploaded" }))
}

async fn delete_media() -> HttpResponse {
    HttpResponse::NoContent().finish()
}

async fn stripe_webhook(state: web::Data<AppState>) -> HttpResponse {
    // Enqueue webhook processing
    let mut queue = state.job_queue.write().await;
    let _ = queue
        .enqueue(
            infrastructure_jobs::JobType::ProcessStripeWebhook {
                event_id: uuid::Uuid::new_v4().to_string(),
                event_type: "invoice.paid".to_string(),
            },
            100,
        )
        .await;

    HttpResponse::Ok().json(serde_json::json!({ "received": true }))
}