// apps/lillpepe/src/main.rs
//! Lillpepe - Complete SaaS Framework Application

use actix_web::{middleware, web, App, HttpServer};
use std::sync::Arc;
use tokio::sync::RwLock;
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};

mod admin;
mod api;
mod auth;
mod routes;

// ============================================================================
// APPLICATION STATE
// ============================================================================

#[derive(Clone)]
pub struct AppState {
    pub db: surrealdb::Surreal<surrealdb::engine::any::Any>,
    pub job_queue: Arc<RwLock<infrastructure_jobs::JobQueue>>,
    pub session_manager: Arc<RwLock<infrastructure_sessions::SessionManager>>,
    pub email_service: Arc<infrastructure_email::EmailService>,
    pub audit_logger: Arc<infrastructure_audit::AuditLogger>,
    pub onboarding_service: Arc<business_onboarding::OnboardingService>,
}

// ============================================================================
// MAIN FUNCTION
// ============================================================================

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    // Initialize tracing
    tracing_subscriber::registry()
        .with(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "info,lillpepe=debug".into()),
        )
        .with(tracing_subscriber::fmt::layer())
        .init();

    tracing::info!("🚀 Starting Lillpepe SaaS Framework");

    // Load configuration
    let config = load_config();

    // ========================================================================
    // 1. CONNECT TO SURREALDB
    // ========================================================================

    tracing::info!("📊 Connecting to SurrealDB: {}", config.database_url);
    let db = surrealdb::engine::any::connect(&config.database_url)
        .await
        .expect("Failed to connect to SurrealDB");

    db.use_ns(&config.database_namespace)
        .use_db(&config.database_name)
        .await
        .expect("Failed to select namespace/database");

    tracing::info!("✓ Connected to {}/{}", config.database_namespace, config.database_name);

    // ========================================================================
    // 2. RUN DATABASE MIGRATIONS
    // ========================================================================

    tracing::info!("🔄 Running database migrations");
    let migration_manager = infrastructure_migrations::MigrationManager::new(
        db.clone(),
        config.migrations_dir.clone(),
    );

    migration_manager
        .init()
        .await
        .expect("Failed to initialize migrations");

    let applied = migration_manager
        .run_pending()
        .await
        .expect("Failed to run migrations");

    if !applied.is_empty() {
        tracing::info!("✓ Applied {} migrations", applied.len());
    } else {
        tracing::info!("✓ No pending migrations");
    }

    // ========================================================================
    // 3. INITIALIZE JOB QUEUE
    // ========================================================================

    tracing::info!("⚙️  Starting background job queue ({} workers)", config.job_workers);
    let job_queue = Arc::new(RwLock::new(
        infrastructure_jobs::JobQueue::new(db.clone(), config.job_workers)
    ));

    // Start job workers in background
    let job_queue_clone = Arc::clone(&job_queue);
    tokio::spawn(async move {
        let queue = job_queue_clone.read().await;
        queue.start().await;
    });

    tracing::info!("✓ Job queue running");

    // ========================================================================
    // 4. INITIALIZE SESSION MANAGER
    // ========================================================================

    tracing::info!("🔐 Initializing session management");
    let session_manager = infrastructure_sessions::SessionManager::new(
        &config.redis_url,
        config.session_ttl,
    )
        .await
        .expect("Failed to connect to Redis");

    let session_manager = Arc::new(RwLock::new(session_manager));
    tracing::info!("✓ Session manager ready");

    // ========================================================================
    // 5. INITIALIZE EMAIL SERVICE
    // ========================================================================

    tracing::info!("📧 Initializing email service");
    let email_service = infrastructure_email::EmailService::new(
        &config.smtp_host,
        config.smtp_port,
        &config.smtp_username,
        &config.smtp_password,
        config.from_email.clone(),
        config.from_name.clone(),
    )
        .expect("Failed to initialize email service");

    let email_service = Arc::new(email_service);
    tracing::info!("✓ Email service ready");

    // ========================================================================
    // 6. INITIALIZE AUDIT LOGGER
    // ========================================================================

    tracing::info!("📝 Initializing audit logging");
    let audit_logger = Arc::new(infrastructure_audit::AuditLogger::new(db.clone()));
    tracing::info!("✓ Audit logger ready");

    // ========================================================================
    // 7. INITIALIZE ONBOARDING SERVICE
    // ========================================================================

    tracing::info!("🎯 Initializing onboarding service");
    let onboarding_service = Arc::new(business_onboarding::OnboardingService::new(
        db.clone(),
        Arc::clone(&job_queue),
        Arc::clone(&session_manager),
    ));
    tracing::info!("✓ Onboarding service ready");

    // ========================================================================
    // 8. CREATE APPLICATION STATE
    // ========================================================================

    let app_state = AppState {
        db: db.clone(),
        job_queue: Arc::clone(&job_queue),
        session_manager: Arc::clone(&session_manager),
        email_service: Arc::clone(&email_service),
        audit_logger: Arc::clone(&audit_logger),
        onboarding_service: Arc::clone(&onboarding_service),
    };

    // ========================================================================
    // 9. SCHEDULE MAINTENANCE JOBS
    // ========================================================================

    let job_queue_maintenance = Arc::clone(&job_queue);
    tokio::spawn(async move {
        schedule_maintenance_jobs(job_queue_maintenance).await;
    });

    // ========================================================================
    // 10. START HTTP SERVER
    // ========================================================================

    let bind_address = format!("{}:{}", config.host, config.port);
    tracing::info!("🌐 Starting HTTP server on {}", bind_address);

    HttpServer::new(move || {
        App::new()
            // Middleware
            .wrap(middleware::Logger::default())
            .wrap(middleware::Compress::default())

            // State
            .app_data(web::Data::new(app_state.clone()))

            // Rate limiting
            .wrap(infrastructure_ratelimit::global_rate_limit(config.redis_url.clone()))

            // Static files
            .service(actix_files::Files::new("/static", "./static"))
            .service(actix_files::Files::new("/media", "./storage/uploads"))

            // Routes
            .configure(routes::configure_public_routes)
            .configure(routes::configure_api_routes)
            .configure(admin::configure_admin_routes)
    })
        .bind(&bind_address)?
        .run()
        .await
}

// ============================================================================
// CONFIGURATION
// ============================================================================

struct Config {
    // Server
    host: String,
    port: u16,

    // Database
    database_url: String,
    database_namespace: String,
    database_name: String,
    migrations_dir: String,

    // Redis
    redis_url: String,
    session_ttl: u64,

    // Jobs
    job_workers: usize,

    // Email
    smtp_host: String,
    smtp_port: u16,
    smtp_username: String,
    smtp_password: String,
    from_email: String,
    from_name: String,
}

fn load_config() -> Config {
    Config {
        host: std::env::var("HOST").unwrap_or_else(|_| "0.0.0.0".to_string()),
        port: std::env::var("PORT")
            .ok()
            .and_then(|p| p.parse().ok())
            .unwrap_or(8080),

        database_url: std::env::var("DATABASE_URL")
            .unwrap_or_else(|_| "ws://localhost:8000".to_string()),
        database_namespace: std::env::var("DATABASE_NAMESPACE")
            .unwrap_or_else(|_| "lillpepe".to_string()),
        database_name: std::env::var("DATABASE_NAME")
            .unwrap_or_else(|_| "main".to_string()),
        migrations_dir: std::env::var("MIGRATIONS_DIR")
            .unwrap_or_else(|_| "migrations".to_string()),

        redis_url: std::env::var("REDIS_URL")
            .unwrap_or_else(|_| "redis://localhost:6379".to_string()),
        session_ttl: std::env::var("SESSION_TTL")
            .ok()
            .and_then(|s| s.parse().ok())
            .unwrap_or(86400), // 24 hours

        job_workers: std::env::var("JOB_WORKERS")
            .ok()
            .and_then(|w| w.parse().ok())
            .unwrap_or(4),

        smtp_host: std::env::var("SMTP_HOST")
            .unwrap_or_else(|_| "smtp.sendgrid.net".to_string()),
        smtp_port: std::env::var("SMTP_PORT")
            .ok()
            .and_then(|p| p.parse().ok())
            .unwrap_or(587),
        smtp_username: std::env::var("SMTP_USERNAME")
            .expect("SMTP_USERNAME must be set"),
        smtp_password: std::env::var("SMTP_PASSWORD")
            .expect("SMTP_PASSWORD must be set"),
        from_email: std::env::var("FROM_EMAIL")
            .unwrap_or_else(|_| "noreply@lillpepe.com".to_string()),
        from_name: std::env::var("FROM_NAME")
            .unwrap_or_else(|_| "Lillpepe".to_string()),
    }
}

// ============================================================================
// MAINTENANCE JOBS
// ============================================================================

async fn schedule_maintenance_jobs(job_queue: Arc<RwLock<infrastructure_jobs::JobQueue>>) {
    use infrastructure_jobs::JobType;
    use tokio::time::{interval, Duration};

    let mut hourly = interval(Duration::from_secs(3600)); // 1 hour
    let mut daily = interval(Duration::from_secs(86400)); // 24 hours

    loop {
        tokio::select! {
            _ = hourly.tick() => {
                let mut queue = job_queue.write().await;
                
                // Cleanup expired sessions
                let _ = queue
                    .enqueue(JobType::CleanupExpiredSessions, 1)
                    .await;
                
                tracing::info!("Scheduled hourly maintenance jobs");
            }
            
            _ = daily.tick() => {
                let mut queue = job_queue.write().await;
                
                // Rotate logs
                let _ = queue
                    .enqueue(JobType::RotateLogs, 1)
                    .await;
                
                // Generate analytics
                let date = chrono::Utc::now().format("%Y-%m-%d").to_string();
                let _ = queue
                    .enqueue(JobType::GenerateAnalytics { date }, 5)
                    .await;
                
                tracing::info!("Scheduled daily maintenance jobs");
            }
        }
    }
}