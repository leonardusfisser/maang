// crates/infrastructure/sessions/src/lib.rs
//! Redis-backed session management with security

use actix_session::{Session, SessionExt};
use actix_web::{dev::Payload, FromRequest, HttpRequest};
use redis::aio::MultiplexedConnection;
use redis::AsyncCommands;
use serde::{Deserialize, Serialize};
use std::future::{ready, Ready};
use std::time::Duration;
use thiserror::Error;
use uuid::Uuid;

#[derive(Error, Debug)]
pub enum SessionError {
    #[error("Redis error: {0}")]
    RedisError(String),

    #[error("Session not found")]
    NotFound,

    #[error("Session expired")]
    Expired,

    #[error("Invalid session data")]
    InvalidData,

    #[error("Unauthorized")]
    Unauthorized,
}

// ============================================================================
// SESSION DATA
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SessionData {
    pub user_id: String,
    pub tenant_id: Option<String>,
    pub email: String,
    pub role: UserRole,
    pub created_at: String,
    pub last_activity: String,
    pub ip_address: String,
    pub user_agent: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "lowercase")]
pub enum UserRole {
    Admin,
    Tenant,
    User,
}

// ============================================================================
// SESSION MANAGER
// ============================================================================

pub struct SessionManager {
    redis: MultiplexedConnection,
    ttl: Duration,
}

impl SessionManager {
    pub async fn new(redis_url: &str, ttl_seconds: u64) -> Result<Self, SessionError> {
        let client = redis::Client::open(redis_url)
            .map_err(|e| SessionError::RedisError(e.to_string()))?;

        let redis = client
            .get_multiplexed_async_connection()
            .await
            .map_err(|e| SessionError::RedisError(e.to_string()))?;

        Ok(Self {
            redis,
            ttl: Duration::from_secs(ttl_seconds),
        })
    }

    pub async fn create_session(
        &mut self,
        user_id: String,
        tenant_id: Option<String>,
        email: String,
        role: UserRole,
        ip_address: String,
        user_agent: String,
    ) -> Result<String, SessionError> {
        let session_id = Uuid::new_v4().to_string();
        let now = chrono::Utc::now().to_rfc3339();

        let session_data = SessionData {
            user_id,
            tenant_id,
            email,
            role,
            created_at: now.clone(),
            last_activity: now,
            ip_address,
            user_agent,
        };

        let session_json = serde_json::to_string(&session_data)
            .map_err(|e| SessionError::RedisError(e.to_string()))?;

        let key = format!("session:{}", session_id);

        self.redis
            .set_ex(&key, session_json, self.ttl.as_secs() as u64)
            .await
            .map_err(|e| SessionError::RedisError(e.to_string()))?;

        tracing::info!("Created session {} for user {}", session_id, session_data.user_id);
        Ok(session_id)
    }

    pub async fn get_session(&mut self, session_id: &str) -> Result<SessionData, SessionError> {
        let key = format!("session:{}", session_id);

        let session_json: Option<String> = self.redis
            .get(&key)
            .await
            .map_err(|e| SessionError::RedisError(e.to_string()))?;

        match session_json {
            Some(json) => {
                let mut session_data: SessionData = serde_json::from_str(&json)
                    .map_err(|_| SessionError::InvalidData)?;

                // Update last activity
                session_data.last_activity = chrono::Utc::now().to_rfc3339();

                let updated_json = serde_json::to_string(&session_data)
                    .map_err(|e| SessionError::RedisError(e.to_string()))?;

                // Refresh TTL
                self.redis
                    .set_ex(&key, updated_json, self.ttl.as_secs() as u64)
                    .await
                    .map_err(|e| SessionError::RedisError(e.to_string()))?;

                Ok(session_data)
            }
            None => Err(SessionError::NotFound),
        }
    }

    pub async fn refresh_session(&mut self, session_id: &str) -> Result<(), SessionError> {
        let key = format!("session:{}", session_id);

        self.redis
            .expire(&key, self.ttl.as_secs() as i64)
            .await
            .map_err(|e| SessionError::RedisError(e.to_string()))?;

        Ok(())
    }

    pub async fn destroy_session(&mut self, session_id: &str) -> Result<(), SessionError> {
        let key = format!("session:{}", session_id);

        self.redis
            .del(&key)
            .await
            .map_err(|e| SessionError::RedisError(e.to_string()))?;

        tracing::info!("Destroyed session {}", session_id);
        Ok(())
    }

    pub async fn destroy_user_sessions(&mut self, user_id: &str) -> Result<usize, SessionError> {
        // Scan for all sessions belonging to user
        let pattern = "session:*";

        let keys: Vec<String> = self.redis
            .keys(pattern)
            .await
            .map_err(|e| SessionError::RedisError(e.to_string()))?;

        let mut destroyed = 0;

        for key in keys {
            let session_json: Option<String> = self.redis
                .get(&key)
                .await
                .map_err(|e| SessionError::RedisError(e.to_string()))?;

            if let Some(json) = session_json {
                if let Ok(session_data) = serde_json::from_str::<SessionData>(&json) {
                    if session_data.user_id == user_id {
                        self.redis
                            .del(&key)
                            .await
                            .map_err(|e| SessionError::RedisError(e.to_string()))?;
                        destroyed += 1;
                    }
                }
            }
        }

        tracing::info!("Destroyed {} sessions for user {}", destroyed, user_id);
        Ok(destroyed)
    }

    pub async fn cleanup_expired(&mut self) -> Result<usize, SessionError> {
        // Redis TTL handles expiry automatically, but this can be used for stats
        let pattern = "session:*";

        let keys: Vec<String> = self.redis
            .keys(pattern)
            .await
            .map_err(|e| SessionError::RedisError(e.to_string()))?;

        Ok(keys.len())
    }

    pub async fn get_active_sessions(&mut self) -> Result<Vec<SessionData>, SessionError> {
        let pattern = "session:*";

        let keys: Vec<String> = self.redis
            .keys(pattern)
            .await
            .map_err(|e| SessionError::RedisError(e.to_string()))?;

        let mut sessions = Vec::new();

        for key in keys {
            let session_json: Option<String> = self.redis
                .get(&key)
                .await
                .map_err(|e| SessionError::RedisError(e.to_string()))?;

            if let Some(json) = session_json {
                if let Ok(session_data) = serde_json::from_str::<SessionData>(&json) {
                    sessions.push(session_data);
                }
            }
        }

        Ok(sessions)
    }
}

// ============================================================================
// ACTIX-WEB INTEGRATION
// ============================================================================

pub struct AuthenticatedUser {
    pub session_data: SessionData,
}

impl FromRequest for AuthenticatedUser {
    type Error = actix_web::Error;
    type Future = Ready<Result<Self, Self::Error>>;

    fn from_request(req: &HttpRequest, _payload: &mut Payload) -> Self::Future {
        let session = req.get_session();

        match session.get::<String>("session_id") {
            Ok(Some(session_id)) => {
                // In production, fetch from Redis here
                // For now, return placeholder
                ready(Err(actix_web::error::ErrorUnauthorized("Not implemented")))
            }
            _ => ready(Err(actix_web::error::ErrorUnauthorized("Not authenticated"))),
        }
    }
}

// ============================================================================
// MIDDLEWARE
// ============================================================================

pub async fn require_auth(
    session: Session,
    req: HttpRequest,
) -> Result<SessionData, actix_web::Error> {
    let session_id = session
        .get::<String>("session_id")
        .map_err(|_| actix_web::error::ErrorUnauthorized("Invalid session"))?
        .ok_or_else(|| actix_web::error::ErrorUnauthorized("Not authenticated"))?;

    // Fetch session from Redis
    // This is a placeholder - actual implementation would use SessionManager
    Err(actix_web::error::ErrorUnauthorized("Session validation not implemented"))
}

pub async fn require_admin(session_data: SessionData) -> Result<(), actix_web::Error> {
    if session_data.role != UserRole::Admin {
        return Err(actix_web::error::ErrorForbidden("Admin access required"));
    }
    Ok(())
}

pub async fn require_tenant(
    session_data: SessionData,
    tenant_id: &str,
) -> Result<(), actix_web::Error> {
    match &session_data.tenant_id {
        Some(t_id) if t_id == tenant_id => Ok(()),
        _ => Err(actix_web::error::ErrorForbidden("Tenant access denied")),
    }
}

// ============================================================================
// SESSION CONFIGURATION
// ============================================================================

pub struct SessionConfig {
    pub redis_url: String,
    pub ttl_seconds: u64,
    pub cookie_name: String,
    pub cookie_secure: bool,
    pub cookie_http_only: bool,
    pub cookie_same_site: String,
}

impl Default for SessionConfig {
    fn default() -> Self {
        Self {
            redis_url: "redis://127.0.0.1:6379".to_string(),
            ttl_seconds: 3600, // 1 hour
            cookie_name: "lillpepe_session".to_string(),
            cookie_secure: true,
            cookie_http_only: true,
            cookie_same_site: "Lax".to_string(),
        }
    }
}

impl SessionConfig {
    pub fn production() -> Self {
        Self {
            redis_url: "redis://127.0.0.1:6379".to_string(),
            ttl_seconds: 86400, // 24 hours
            cookie_name: "lillpepe_session".to_string(),
            cookie_secure: true,
            cookie_http_only: true,
            cookie_same_site: "Strict".to_string(),
        }
    }

    pub fn development() -> Self {
        Self {
            redis_url: "redis://127.0.0.1:6379".to_string(),
            ttl_seconds: 3600,
            cookie_name: "lillpepe_session_dev".to_string(),
            cookie_secure: false,
            cookie_http_only: true,
            cookie_same_site: "Lax".to_string(),
        }
    }
}