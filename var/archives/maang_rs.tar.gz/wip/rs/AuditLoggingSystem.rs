// crates/infrastructure/audit/src/lib.rs
//! Comprehensive audit logging for compliance and debugging

use serde::{Deserialize, Serialize};
use serde_json::Value;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum AuditError {
    #[error("Database error: {0}")]
    DatabaseError(String),

    #[error("Serialization error: {0}")]
    SerializationError(String),
}

// ============================================================================
// AUDIT LOG ENTRY
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuditLog {
    pub id: String,
    pub user_id: Option<String>,
    pub white_label_id: Option<String>,
    pub action: AuditAction,
    pub resource_type: String,
    pub resource_id: String,
    pub ip_address: String,
    pub user_agent: String,
    pub metadata: Value,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AuditAction {
    // Authentication
    LoginSuccess,
    LoginFailed,
    Logout,
    PasswordChanged,
    PasswordResetRequested,

    // Users
    UserCreated,
    UserUpdated,
    UserDeleted,
    UserRoleChanged,

    // Tenants
    TenantCreated,
    TenantUpdated,
    TenantDeleted,
    TenantProvisioned,
    TenantSuspended,
    TenantActivated,

    // Products/Services
    ProductCreated,
    ProductUpdated,
    ProductDeleted,
    ServiceCreated,
    ServiceUpdated,
    ServiceDeleted,

    // Payments
    PaymentProcessed,
    PaymentFailed,
    SubscriptionCreated,
    SubscriptionUpdated,
    SubscriptionCancelled,
    InvoiceGenerated,

    // Media
    FileUploaded,
    FileDeleted,

    // Configuration
    SettingsUpdated,
    ColorsChanged,
    DomainChanged,

    // Admin Actions
    AdminAccessGranted,
    AdminActionPerformed,
    DataExported,
    DataDeleted,
}

impl AuditAction {
    pub fn severity(&self) -> AuditSeverity {
        match self {
            Self::LoginFailed | Self::PaymentFailed | Self::TenantSuspended => {
                AuditSeverity::Warning
            }
            Self::UserDeleted
            | Self::TenantDeleted
            | Self::DataDeleted
            | Self::AdminActionPerformed => AuditSeverity::Critical,
            _ => AuditSeverity::Info,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum AuditSeverity {
    Info,
    Warning,
    Critical,
}

// ============================================================================
// AUDIT LOGGER
// ============================================================================

pub struct AuditLogger {
    db: surrealdb::Surreal<surrealdb::engine::any::Any>,
}

impl AuditLogger {
    pub fn new(db: surrealdb::Surreal<surrealdb::engine::any::Any>) -> Self {
        Self { db }
    }

    pub async fn log(
        &self,
        user_id: Option<String>,
        white_label_id: Option<String>,
        action: AuditAction,
        resource_type: String,
        resource_id: String,
        ip_address: String,
        user_agent: String,
        metadata: Value,
    ) -> Result<String, AuditError> {
        let log_id = uuid::Uuid::new_v4().to_string();

        let audit_log = AuditLog {
            id: log_id.clone(),
            user_id,
            white_label_id,
            action,
            resource_type,
            resource_id,
            ip_address,
            user_agent,
            metadata,
            created_at: chrono::Utc::now().to_rfc3339(),
        };

        let _: Option<AuditLog> = self.db
            .create(("audit_log", &audit_log.id))
            .content(&audit_log)
            .await
            .map_err(|e| AuditError::DatabaseError(e.to_string()))?;

        tracing::info!(
            "Audit log: {:?} - {} by {:?}",
            audit_log.action,
            audit_log.resource_type,
            audit_log.user_id
        );

        Ok(log_id)
    }

    pub async fn query(
        &self,
        filters: AuditQueryFilters,
    ) -> Result<Vec<AuditLog>, AuditError> {
        let mut query = String::from("SELECT * FROM audit_log WHERE 1=1");

        if let Some(user_id) = filters.user_id {
            query.push_str(&format!(" AND user_id = '{}'", user_id));
        }

        if let Some(white_label_id) = filters.white_label_id {
            query.push_str(&format!(" AND white_label_id = '{}'", white_label_id));
        }

        if let Some(resource_type) = filters.resource_type {
            query.push_str(&format!(" AND resource_type = '{}'", resource_type));
        }

        if let Some(start_date) = filters.start_date {
            query.push_str(&format!(" AND created_at >= '{}'", start_date));
        }

        if let Some(end_date) = filters.end_date {
            query.push_str(&format!(" AND created_at <= '{}'", end_date));
        }

        query.push_str(" ORDER BY created_at DESC");

        if let Some(limit) = filters.limit {
            query.push_str(&format!(" LIMIT {}", limit));
        }

        let logs: Vec<AuditLog> = self.db
            .query(&query)
            .await
            .map_err(|e| AuditError::DatabaseError(e.to_string()))?
            .take(0)
            .map_err(|e| AuditError::DatabaseError(e.to_string()))?;

        Ok(logs)
    }

    pub async fn get_user_activity(
        &self,
        user_id: &str,
        days: i64,
    ) -> Result<Vec<AuditLog>, AuditError> {
        let start_date = chrono::Utc::now() - chrono::Duration::days(days);

        self.query(AuditQueryFilters {
            user_id: Some(user_id.to_string()),
            white_label_id: None,
            resource_type: None,
            start_date: Some(start_date.to_rfc3339()),
            end_date: None,
            limit: Some(100),
        })
            .await
    }

    pub async fn get_tenant_activity(
        &self,
        white_label_id: &str,
        days: i64,
    ) -> Result<Vec<AuditLog>, AuditError> {
        let start_date = chrono::Utc::now() - chrono::Duration::days(days);

        self.query(AuditQueryFilters {
            user_id: None,
            white_label_id: Some(white_label_id.to_string()),
            resource_type: None,
            start_date: Some(start_date.to_rfc3339()),
            end_date: None,
            limit: Some(100),
        })
            .await
    }

    pub async fn export_logs(
        &self,
        filters: AuditQueryFilters,
        format: ExportFormat,
    ) -> Result<String, AuditError> {
        let logs = self.query(filters).await?;

        match format {
            ExportFormat::Json => {
                serde_json::to_string_pretty(&logs)
                    .map_err(|e| AuditError::SerializationError(e.to_string()))
            }
            ExportFormat::Csv => {
                let mut csv = String::from("timestamp,user_id,action,resource_type,resource_id,ip_address\n");

                for log in logs {
                    csv.push_str(&format!(
                        "{},{:?},{:?},{},{},{}\n",
                        log.created_at,
                        log.user_id,
                        log.action,
                        log.resource_type,
                        log.resource_id,
                        log.ip_address
                    ));
                }

                Ok(csv)
            }
        }
    }
}

#[derive(Debug, Clone, Default)]
pub struct AuditQueryFilters {
    pub user_id: Option<String>,
    pub white_label_id: Option<String>,
    pub resource_type: Option<String>,
    pub start_date: Option<String>,
    pub end_date: Option<String>,
    pub limit: Option<usize>,
}

#[derive(Debug, Clone)]
pub enum ExportFormat {
    Json,
    Csv,
}

// ============================================================================
// CONVENIENCE MACROS
// ============================================================================

#[macro_export]
macro_rules! audit {
    ($logger:expr, $user_id:expr, $tenant_id:expr, $action:expr, $resource_type:expr, $resource_id:expr, $req:expr) => {
        {
            let ip = $req.connection_info().peer_addr().unwrap_or("unknown").to_string();
            let ua = $req.headers()
                .get("user-agent")
                .and_then(|v| v.to_str().ok())
                .unwrap_or("unknown")
                .to_string();
            
            $logger.log(
                $user_id,
                $tenant_id,
                $action,
                $resource_type.to_string(),
                $resource_id.to_string(),
                ip,
                ua,
                serde_json::json!({}),
            ).await
        }
    };
    
    ($logger:expr, $user_id:expr, $tenant_id:expr, $action:expr, $resource_type:expr, $resource_id:expr, $req:expr, $metadata:expr) => {
        {
            let ip = $req.connection_info().peer_addr().unwrap_or("unknown").to_string();
            let ua = $req.headers()
                .get("user-agent")
                .and_then(|v| v.to_str().ok())
                .unwrap_or("unknown")
                .to_string();
            
            $logger.log(
                $user_id,
                $tenant_id,
                $action,
                $resource_type.to_string(),
                $resource_id.to_string(),
                ip,
                ua,
                $metadata,
            ).await
        }
    };
}

// ============================================================================
// ACTIX-WEB INTEGRATION
// ============================================================================

use actix_web::{web, HttpRequest, HttpResponse};

pub async fn get_audit_logs(
    logger: web::Data<AuditLogger>,
    query: web::Query<AuditQueryFilters>,
) -> HttpResponse {
    match logger.query(query.into_inner()).await {
        Ok(logs) => HttpResponse::Ok().json(logs),
        Err(e) => HttpResponse::InternalServerError().json(serde_json::json!({
            "error": e.to_string()
        })),
    }
}

pub async fn export_audit_logs(
    logger: web::Data<AuditLogger>,
    query: web::Query<AuditQueryFilters>,
    format: web::Path<String>,
) -> HttpResponse {
    let export_format = match format.as_str() {
        "json" => ExportFormat::Json,
        "csv" => ExportFormat::Csv,
        _ => return HttpResponse::BadRequest().json(serde_json::json!({
            "error": "Invalid format. Use 'json' or 'csv'"
        })),
    };

    match logger.export_logs(query.into_inner(), export_format).await {
        Ok(data) => HttpResponse::Ok().body(data),
        Err(e) => HttpResponse::InternalServerError().json(serde_json::json!({
            "error": e.to_string()
        })),
    }
}