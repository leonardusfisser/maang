// tools/migrate/src/main.rs
//! Database migration CLI tool

use infrastructure_migrations::{MigrationManager, MigrationError};

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    tracing_subscriber::fmt::init();

    let args: Vec<String> = std::env::args().collect();

    if args.len() < 2 {
        print_usage();
        return Ok(());
    }

    // Connect to database
    let db_url = std::env::var("DATABASE_URL")
        .unwrap_or_else(|_| "ws://localhost:8000".to_string());

    let namespace = std::env::var("DATABASE_NAMESPACE")
        .unwrap_or_else(|_| "lillpepe".to_string());

    let database = std::env::var("DATABASE_NAME")
        .unwrap_or_else(|_| "main".to_string());

    println!("Connecting to {}...", db_url);
    let db = surrealdb::engine::any::connect(&db_url).await?;
    db.use_ns(&namespace).use_db(&database).await?;
    println!("✓ Connected to {}/{}", namespace, database);

    let migrations_dir = std::env::var("MIGRATIONS_DIR")
        .unwrap_or_else(|_| "migrations".to_string());

    let manager = MigrationManager::new(db, migrations_dir);

    match args[1].as_str() {
        "init" => cmd_init(&manager).await?,
        "run" => cmd_run(&manager).await?,
        "status" => cmd_status(&manager).await?,
        "rollback" => cmd_rollback(&manager).await?,
        "create" => cmd_create(&args).await?,
        _ => {
            eprintln!("Unknown command: {}", args[1]);
            print_usage();
            std::process::exit(1);
        }
    }

    Ok(())
}

fn print_usage() {
    println!("Lillpepe Migration Tool");
    println!("\nUsage: migrate <command> [options]");
    println!("\nCommands:");
    println!("  init              Initialize migrations table");
    println!("  run               Run all pending migrations");
    println!("  status            Show migration status");
    println!("  rollback          Rollback last migration");
    println!("  create <name>     Create new migration file");
    println!("\nEnvironment Variables:");
    println!("  DATABASE_URL      Database connection URL (default: ws://localhost:8000)");
    println!("  DATABASE_NAMESPACE  Database namespace (default: lillpepe)");
    println!("  DATABASE_NAME     Database name (default: main)");
    println!("  MIGRATIONS_DIR    Migrations directory (default: ./migrations)");
}

async fn cmd_init(manager: &MigrationManager) -> Result<(), MigrationError> {
    println!("Initializing migrations table...");
    manager.init().await?;
    println!("✓ Migrations table initialized");
    Ok(())
}

async fn cmd_run(manager: &MigrationManager) -> Result<(), MigrationError> {
    println!("Running pending migrations...");
    let applied = manager.run_pending().await?;

    if applied.is_empty() {
        println!("✓ No pending migrations");
    } else {
        println!("✓ Applied {} migration(s):", applied.len());
        for migration in applied {
            println!("  ✓ {}", migration);
        }
    }

    Ok(())
}

async fn cmd_status(manager: &MigrationManager) -> Result<(), MigrationError> {
    let status = manager.status().await?;

    println!("\n╔══════════════════════════════════════╗");
    println!("║     Migration Status                 ║");
    println!("╠══════════════════════════════════════╣");
    println!("║  Total:   {:<27}║", status.total);
    println!("║  Applied: {:<27}║", status.applied);
    println!("║  Pending: {:<27}║", status.pending);
    println!("╚══════════════════════════════════════╝\n");

    if !status.migrations.is_empty() {
        println!("Applied Migrations:");
        println!("───────────────────────────────────────────────────────────");
        for migration in status.migrations {
            println!("  {} - {}", migration.version, migration.name);
            println!("    Applied: {}", migration.applied_at);
            println!("    Checksum: {}", migration.checksum);
            println!();
        }
    }

    Ok(())
}

async fn cmd_rollback(manager: &MigrationManager) -> Result<(), MigrationError> {
    println!("⚠  Rolling back last migration...");
    println!("⚠  WARNING: This will NOT undo schema changes!");
    println!("⚠  This only removes the migration record from the database.");
    println!();

    manager.rollback_last().await?;
    println!("✓ Last migration rolled back");

    Ok(())
}

async fn cmd_create(args: &[String]) -> Result<(), Box<dyn std::error::Error>> {
    if args.len() < 3 {
        eprintln!("Error: Migration name required");
        eprintln!("Usage: migrate create <name>");
        std::process::exit(1);
    }

    let name = args[2..].join("_").to_lowercase();
    let migrations_dir = std::env::var("MIGRATIONS_DIR")
        .unwrap_or_else(|_| "migrations".to_string());

    // Find next version number
    let next_version = find_next_version(&migrations_dir)?;
    let filename = format!("{}_{}.surql", next_version, name);
    let filepath = std::path::Path::new(&migrations_dir).join(&filename);

    // Create migrations directory if it doesn't exist
    std::fs::create_dir_all(&migrations_dir)?;

    // Create migration file with template
    let template = format!(
        r#"-- Migration: {}
-- Created: {}

-- Add your migration SQL here
-- Example:
-- DEFINE TABLE example SCHEMAFULL;
-- DEFINE FIELD name ON example TYPE string;
"#,
        name,
        chrono::Utc::now().format("%Y-%m-%d %H:%M:%S")
    );

    std::fs::write(&filepath, template)?;

    println!("✓ Created migration: {}", filename);
    println!("  Path: {}", filepath.display());

    Ok(())
}

fn find_next_version(migrations_dir: &str) -> Result<String, Box<dyn std::error::Error>> {
    let path = std::path::Path::new(migrations_dir);

    if !path.exists() {
        return Ok("001".to_string());
    }

    let mut max_version = 0;

    for entry in std::fs::read_dir(path)? {
        let entry = entry?;
        let filename = entry.file_name();
        let filename_str = filename.to_string_lossy();

        if !filename_str.ends_with(".surql") {
            continue;
        }

        // Parse version from filename (e.g., "001_initial.surql" -> 1)
        if let Some(version_str) = filename_str.split('_').next() {
            if let Ok(version) = version_str.parse::<u32>() {
                max_version = max_version.max(version);
            }
        }
    }

    Ok(format!("{:03}", max_version + 1))
}

// ============================================================================
// CARGO.TOML
// ============================================================================

/*
[package]
name = "migrate"
version = "0.1.0"
edition = "2021"

[[bin]]
name = "migrate"
path = "src/main.rs"

[dependencies]
infrastructure-migrations = { path = "../../crates/infrastructure/migrations" }
surrealdb = { version = "2", default-features = false }
tokio = { version = "1", features = ["full"] }
tracing = "0.1"
tracing-subscriber = "0.3"
*/"