// apps/lillpepe/src/main.rs (integration snippet)

use actix_web::{web, App, HttpServer};
use infrastructure_storage::{FileUploadHandler, StorageState, configure_routes};
use std::path::PathBuf;
use std::sync::Arc;

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    // Initialize SurrealDB
    let db = surrealdb::engine::any::connect("ws://localhost:8000")
        .await
        .expect("Failed to connect to SurrealDB");

    db.use_ns("lillpepe").use_db("main")
        .await
        .expect("Failed to select namespace/database");

    // Initialize storage handler
    let storage_root = PathBuf::from("./storage/uploads");
    let storage_handler = Arc::new(FileUploadHandler::new(storage_root, db));

    let storage_state = StorageState {
        handler: storage_handler,
    };

    // Start HTTP server
    HttpServer::new(move || {
        App::new()
            .app_data(web::Data::new(storage_state.clone()))
            .configure(configure_routes)
            // Add static file serving for uploaded media
            .service(
                actix_files::Files::new("/media", "./storage/uploads")
                    .show_files_listing()
            )
    })
        .bind(("0.0.0.0", 8080))?
        .run()
        .await
}