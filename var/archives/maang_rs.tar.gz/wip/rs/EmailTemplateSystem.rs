// crates/infrastructure/email/src/lib.rs
//! Email system with templates and SMTP

use askama::Template;
use lettre::{
    message::{header, MultiPart, SinglePart},
    transport::smtp::authentication::Credentials,
    Message, SmtpTransport, Transport,
};
use serde::{Deserialize, Serialize};
use thiserror::Error;

#[derive(Error, Debug)]
pub enum EmailError {
    #[error("SMTP error: {0}")]
    SmtpError(String),

    #[error("Template error: {0}")]
    TemplateError(String),

    #[error("Invalid email address: {0}")]
    InvalidAddress(String),
}

// ============================================================================
// EMAIL TEMPLATES
// ============================================================================

#[derive(Template)]
#[template(path = "emails/welcome.html")]
pub struct WelcomeEmail {
    pub user_name: String,
    pub login_url: String,
}

#[derive(Template)]
#[template(path = "emails/password_reset.html")]
pub struct PasswordResetEmail {
    pub user_name: String,
    pub reset_url: String,
    pub expires_in: String,
}

#[derive(Template)]
#[template(path = "emails/invoice.html")]
pub struct InvoiceEmail {
    pub tenant_name: String,
    pub invoice_number: String,
    pub amount: String,
    pub currency: String,
    pub due_date: String,
    pub invoice_url: String,
}

#[derive(Template)]
#[template(path = "emails/subscription_created.html")]
pub struct SubscriptionCreatedEmail {
    pub tenant_name: String,
    pub plan_name: String,
    pub amount: String,
    pub interval: String,
    pub next_billing: String,
}

#[derive(Template)]
#[template(path = "emails/subscription_cancelled.html")]
pub struct SubscriptionCancelledEmail {
    pub tenant_name: String,
    pub cancellation_date: String,
}

#[derive(Template)]
#[template(path = "emails/payment_failed.html")]
pub struct PaymentFailedEmail {
    pub tenant_name: String,
    pub amount: String,
    pub reason: String,
    pub update_payment_url: String,
}

#[derive(Template)]
#[template(path = "emails/tenant_provisioned.html")]
pub struct TenantProvisionedEmail {
    pub tenant_name: String,
    pub domain: String,
    pub dashboard_url: String,
}

// ============================================================================
// EMAIL SERVICE
// ============================================================================

pub struct EmailService {
    mailer: SmtpTransport,
    from_email: String,
    from_name: String,
}

impl EmailService {
    pub fn new(
        smtp_host: &str,
        smtp_port: u16,
        smtp_username: &str,
        smtp_password: &str,
        from_email: String,
        from_name: String,
    ) -> Result<Self, EmailError> {
        let credentials = Credentials::new(
            smtp_username.to_string(),
            smtp_password.to_string(),
        );

        let mailer = SmtpTransport::relay(smtp_host)
            .map_err(|e| EmailError::SmtpError(e.to_string()))?
            .port(smtp_port)
            .credentials(credentials)
            .build();

        Ok(Self {
            mailer,
            from_email,
            from_name,
        })
    }

    pub async fn send_welcome(
        &self,
        to_email: &str,
        to_name: &str,
        user_name: &str,
        login_url: &str,
    ) -> Result<(), EmailError> {
        let template = WelcomeEmail {
            user_name: user_name.to_string(),
            login_url: login_url.to_string(),
        };

        let html = template
            .render()
            .map_err(|e| EmailError::TemplateError(e.to_string()))?;

        self.send_email(
            to_email,
            to_name,
            "Welcome to Lillpepe",
            &html,
            &format!("Welcome to Lillpepe, {}!", user_name),
        )
            .await
    }

    pub async fn send_password_reset(
        &self,
        to_email: &str,
        to_name: &str,
        reset_url: &str,
    ) -> Result<(), EmailError> {
        let template = PasswordResetEmail {
            user_name: to_name.to_string(),
            reset_url: reset_url.to_string(),
            expires_in: "1 hour".to_string(),
        };

        let html = template
            .render()
            .map_err(|e| EmailError::TemplateError(e.to_string()))?;

        self.send_email(
            to_email,
            to_name,
            "Reset Your Password",
            &html,
            "Click the link to reset your password",
        )
            .await
    }

    pub async fn send_invoice(
        &self,
        to_email: &str,
        tenant_name: &str,
        invoice: InvoiceData,
    ) -> Result<(), EmailError> {
        let template = InvoiceEmail {
            tenant_name: tenant_name.to_string(),
            invoice_number: invoice.number,
            amount: invoice.amount,
            currency: invoice.currency,
            due_date: invoice.due_date,
            invoice_url: invoice.url,
        };

        let html = template
            .render()
            .map_err(|e| EmailError::TemplateError(e.to_string()))?;

        self.send_email(
            to_email,
            tenant_name,
            &format!("Invoice {}", template.invoice_number),
            &html,
            &format!("Your invoice for {} is ready", template.amount),
        )
            .await
    }

    pub async fn send_subscription_created(
        &self,
        to_email: &str,
        tenant_name: &str,
        plan_name: &str,
        amount: &str,
        interval: &str,
        next_billing: &str,
    ) -> Result<(), EmailError> {
        let template = SubscriptionCreatedEmail {
            tenant_name: tenant_name.to_string(),
            plan_name: plan_name.to_string(),
            amount: amount.to_string(),
            interval: interval.to_string(),
            next_billing: next_billing.to_string(),
        };

        let html = template
            .render()
            .map_err(|e| EmailError::TemplateError(e.to_string()))?;

        self.send_email(
            to_email,
            tenant_name,
            "Subscription Activated",
            &html,
            &format!("Your {} subscription is now active", plan_name),
        )
            .await
    }

    pub async fn send_subscription_cancelled(
        &self,
        to_email: &str,
        tenant_name: &str,
        cancellation_date: &str,
    ) -> Result<(), EmailError> {
        let template = SubscriptionCancelledEmail {
            tenant_name: tenant_name.to_string(),
            cancellation_date: cancellation_date.to_string(),
        };

        let html = template
            .render()
            .map_err(|e| EmailError::TemplateError(e.to_string()))?;

        self.send_email(
            to_email,
            tenant_name,
            "Subscription Cancelled",
            &html,
            "Your subscription has been cancelled",
        )
            .await
    }

    pub async fn send_payment_failed(
        &self,
        to_email: &str,
        tenant_name: &str,
        amount: &str,
        reason: &str,
        update_payment_url: &str,
    ) -> Result<(), EmailError> {
        let template = PaymentFailedEmail {
            tenant_name: tenant_name.to_string(),
            amount: amount.to_string(),
            reason: reason.to_string(),
            update_payment_url: update_payment_url.to_string(),
        };

        let html = template
            .render()
            .map_err(|e| EmailError::TemplateError(e.to_string()))?;

        self.send_email(
            to_email,
            tenant_name,
            "Payment Failed",
            &html,
            &format!("Payment of {} failed", amount),
        )
            .await
    }

    pub async fn send_tenant_provisioned(
        &self,
        to_email: &str,
        tenant_name: &str,
        domain: &str,
        dashboard_url: &str,
    ) -> Result<(), EmailError> {
        let template = TenantProvisionedEmail {
            tenant_name: tenant_name.to_string(),
            domain: domain.to_string(),
            dashboard_url: dashboard_url.to_string(),
        };

        let html = template
            .render()
            .map_err(|e| EmailError::TemplateError(e.to_string()))?;

        self.send_email(
            to_email,
            tenant_name,
            "Your Site is Ready!",
            &html,
            &format!("Your white label site at {} is ready", domain),
        )
            .await
    }

    async fn send_email(
        &self,
        to_email: &str,
        to_name: &str,
        subject: &str,
        html_body: &str,
        text_body: &str,
    ) -> Result<(), EmailError> {
        let email = Message::builder()
            .from(
                format!("{} <{}>", self.from_name, self.from_email)
                    .parse()
                    .map_err(|e| EmailError::InvalidAddress(format!("{}", e)))?,
            )
            .to(
                format!("{} <{}>", to_name, to_email)
                    .parse()
                    .map_err(|e| EmailError::InvalidAddress(format!("{}", e)))?,
            )
            .subject(subject)
            .multipart(
                MultiPart::alternative()
                    .singlepart(
                        SinglePart::builder()
                            .header(header::ContentType::TEXT_PLAIN)
                            .body(text_body.to_string()),
                    )
                    .singlepart(
                        SinglePart::builder()
                            .header(header::ContentType::TEXT_HTML)
                            .body(html_body.to_string()),
                    ),
            )
            .map_err(|e| EmailError::SmtpError(e.to_string()))?;

        self.mailer
            .send(&email)
            .map_err(|e| EmailError::SmtpError(e.to_string()))?;

        tracing::info!("Email sent to {}: {}", to_email, subject);
        Ok(())
    }
}

// ============================================================================
// DATA STRUCTURES
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InvoiceData {
    pub number: String,
    pub amount: String,
    pub currency: String,
    pub due_date: String,
    pub url: String,
}

// ============================================================================
// INTEGRATION WITH JOB QUEUE
// ============================================================================

pub async fn process_email_job(
    email_service: &EmailService,
    job_type: &infrastructure_jobs::JobType,
) -> Result<(), EmailError> {
    use infrastructure_jobs::JobType;

    match job_type {
        JobType::SendWelcomeEmail { user_id, email } => {
            email_service
                .send_welcome(
                    email,
                    "User",
                    "User",
                    &format!("https://lillpepe.com/login?user={}", user_id),
                )
                .await
        }

        JobType::SendPasswordReset { user_id, token } => {
            email_service
                .send_password_reset(
                    "user@example.com", // Fetch from DB
                    "User",
                    &format!("https://lillpepe.com/reset?token={}", token),
                )
                .await
        }

        JobType::SendInvoiceEmail { invoice_id, tenant_id } => {
            // Fetch invoice details from DB
            let invoice_data = InvoiceData {
                number: invoice_id.clone(),
                amount: "€50.00".to_string(),
                currency: "EUR".to_string(),
                due_date: chrono::Utc::now().to_rfc3339(),
                url: format!("https://lillpepe.com/invoices/{}", invoice_id),
            };

            email_service
                .send_invoice("tenant@example.com", "Tenant", invoice_data)
                .await
        }

        _ => Ok(()), // Not an email job
    }
}