// crates/infrastructure/migrations/src/lib.rs
//! Database migration system for SurrealDB

use serde::{Deserialize, Serialize};
use std::path::Path;
use thiserror::Error;
use tracing::{info, warn};

#[derive(Error, Debug)]
pub enum MigrationError {
    #[error("Database error: {0}")]
    DatabaseError(String),

    #[error("Migration file error: {0}")]
    FileError(String),

    #[error("Migration already applied: {0}")]
    AlreadyApplied(String),

    #[error("Migration not found: {0}")]
    NotFound(String),
}

// ============================================================================
// MIGRATION RECORD
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Migration {
    pub id: String,
    pub version: String,
    pub name: String,
    pub applied_at: String,
    pub checksum: String,
}

// ============================================================================
// MIGRATION MANAGER
// ============================================================================

pub struct MigrationManager {
    db: surrealdb::Surreal<surrealdb::engine::any::Any>,
    migrations_dir: String,
}

impl MigrationManager {
    pub fn new(
        db: surrealdb::Surreal<surrealdb::engine::any::Any>,
        migrations_dir: String,
    ) -> Self {
        Self { db, migrations_dir }
    }

    pub async fn init(&self) -> Result<(), MigrationError> {
        info!("Initializing migrations table");

        self.db
            .query(r#"
                DEFINE TABLE migrations SCHEMAFULL;
                DEFINE FIELD id ON migrations TYPE string;
                DEFINE FIELD version ON migrations TYPE string;
                DEFINE FIELD name ON migrations TYPE string;
                DEFINE FIELD applied_at ON migrations TYPE datetime;
                DEFINE FIELD checksum ON migrations TYPE string;
                DEFINE INDEX idx_migrations_version ON migrations FIELDS version UNIQUE;
            "#)
            .await
            .map_err(|e| MigrationError::DatabaseError(e.to_string()))?;

        Ok(())
    }

    pub async fn run_pending(&self) -> Result<Vec<String>, MigrationError> {
        info!("Running pending migrations");

        let migration_files = self.discover_migrations()?;
        let applied_migrations = self.get_applied_migrations().await?;

        let mut applied = Vec::new();

        for (version, name, content) in migration_files {
            if applied_migrations.iter().any(|m| m.version == version) {
                info!("Migration {} already applied, skipping", version);
                continue;
            }

            info!("Applying migration: {} - {}", version, name);
            self.apply_migration(&version, &name, &content).await?;
            applied.push(format!("{} - {}", version, name));
        }

        if applied.is_empty() {
            info!("No pending migrations");
        } else {
            info!("Applied {} migrations", applied.len());
        }

        Ok(applied)
    }

    pub async fn status(&self) -> Result<MigrationStatus, MigrationError> {
        let migration_files = self.discover_migrations()?;
        let applied_migrations = self.get_applied_migrations().await?;

        let total = migration_files.len();
        let applied = applied_migrations.len();
        let pending = total - applied;

        Ok(MigrationStatus {
            total,
            applied,
            pending,
            migrations: applied_migrations,
        })
    }

    fn discover_migrations(&self) -> Result<Vec<(String, String, String)>, MigrationError> {
        let path = Path::new(&self.migrations_dir);

        if !path.exists() {
            return Err(MigrationError::FileError(format!(
                "Migrations directory not found: {}",
                self.migrations_dir
            )));
        }

        let mut migrations = Vec::new();

        for entry in std::fs::read_dir(path)
            .map_err(|e| MigrationError::FileError(e.to_string()))?
        {
            let entry = entry.map_err(|e| MigrationError::FileError(e.to_string()))?;
            let file_name = entry.file_name();
            let file_name_str = file_name.to_string_lossy();

            if !file_name_str.ends_with(".surql") {
                continue;
            }

            // Parse filename: 001_initial_schema.surql
            let parts: Vec<&str> = file_name_str.split('_').collect();
            if parts.is_empty() {
                warn!("Invalid migration filename: {}", file_name_str);
                continue;
            }

            let version = parts[0].to_string();
            let name = file_name_str
                .trim_end_matches(".surql")
                .trim_start_matches(&format!("{}_", version))
                .to_string();

            let content = std::fs::read_to_string(entry.path())
                .map_err(|e| MigrationError::FileError(e.to_string()))?;

            migrations.push((version, name, content));
        }

        // Sort by version
        migrations.sort_by(|a, b| a.0.cmp(&b.0));

        Ok(migrations)
    }

    async fn get_applied_migrations(&self) -> Result<Vec<Migration>, MigrationError> {
        let migrations: Vec<Migration> = self.db
            .query("SELECT * FROM migrations ORDER BY version ASC")
            .await
            .map_err(|e| MigrationError::DatabaseError(e.to_string()))?
            .take(0)
            .map_err(|e| MigrationError::DatabaseError(e.to_string()))?;

        Ok(migrations)
    }

    async fn apply_migration(
        &self,
        version: &str,
        name: &str,
        content: &str,
    ) -> Result<(), MigrationError> {
        // Calculate checksum
        let checksum = format!("{:x}", md5::compute(content.as_bytes()));

        // Execute migration
        self.db
            .query(content)
            .await
            .map_err(|e| MigrationError::DatabaseError(e.to_string()))?;

        // Record migration
        let migration = Migration {
            id: uuid::Uuid::new_v4().to_string(),
            version: version.to_string(),
            name: name.to_string(),
            applied_at: chrono::Utc::now().to_rfc3339(),
            checksum,
        };

        let _: Option<Migration> = self.db
            .create(("migrations", &migration.id))
            .content(&migration)
            .await
            .map_err(|e| MigrationError::DatabaseError(e.to_string()))?;

        info!("Migration {} applied successfully", version);
        Ok(())
    }

    pub async fn rollback_last(&self) -> Result<(), MigrationError> {
        let migrations = self.get_applied_migrations().await?;

        if let Some(last_migration) = migrations.last() {
            warn!("Rolling back migration: {}", last_migration.version);

            // Delete migration record
            let _: Option<Migration> = self.db
                .delete(("migrations", &last_migration.id))
                .await
                .map_err(|e| MigrationError::DatabaseError(e.to_string()))?;

            info!("Migration {} rolled back", last_migration.version);
            Ok(())
        } else {
            Err(MigrationError::NotFound("No migrations to rollback".to_string()))
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct MigrationStatus {
    pub total: usize,
    pub applied: usize,
    pub pending: usize,
    pub migrations: Vec<Migration>,
}

// ============================================================================
// CLI TOOL
// ============================================================================

pub async fn run_migrations_cli() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = std::env::args().collect();

    if args.len() < 2 {
        println!("Usage: migrate <command>");
        println!("\nCommands:");
        println!("  init     - Initialize migrations table");
        println!("  run      - Run pending migrations");
        println!("  status   - Show migration status");
        println!("  rollback - Rollback last migration");
        return Ok(());
    }

    let db = surrealdb::engine::any::connect("ws://localhost:8000").await?;
    db.use_ns("lillpepe").use_db("main").await?;

    let manager = MigrationManager::new(db, "migrations".to_string());

    match args[1].as_str() {
        "init" => {
            manager.init().await?;
            println!("✓ Migrations table initialized");
        }

        "run" => {
            let applied = manager.run_pending().await?;
            if applied.is_empty() {
                println!("✓ No pending migrations");
            } else {
                println!("✓ Applied {} migrations:", applied.len());
                for migration in applied {
                    println!("  - {}", migration);
                }
            }
        }

        "status" => {
            let status = manager.status().await?;
            println!("Migration Status:");
            println!("  Total:   {}", status.total);
            println!("  Applied: {}", status.applied);
            println!("  Pending: {}", status.pending);
            println!("\nApplied migrations:");
            for migration in status.migrations {
                println!("  {} - {} ({})", migration.version, migration.name, migration.applied_at);
            }
        }

        "rollback" => {
            manager.rollback_last().await?;
            println!("✓ Last migration rolled back");
        }

        _ => {
            eprintln!("Unknown command: {}", args[1]);
            std::process::exit(1);
        }
    }

    Ok(())
}