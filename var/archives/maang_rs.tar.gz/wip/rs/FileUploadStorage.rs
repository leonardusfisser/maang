// crates/infrastructure/storage/src/lib.rs
//! File storage and upload handling with tenant isolation

use actix_multipart::Multipart;
use actix_web::{web, Error, HttpResponse};
use futures_util::TryStreamExt;
use serde::{Deserialize, Serialize};
use std::io::Write;
use std::path::{Path, PathBuf};
use thiserror::Error as ThisError;
use tokio::fs;
use uuid::Uuid;

#[derive(ThisError, Debug)]
pub enum StorageError {
    #[error("Invalid file type: {0}")]
    InvalidFileType(String),

    #[error("File too large: {0} bytes (max: {1})")]
    FileTooLarge(usize, usize),

    #[error("Storage error: {0}")]
    IoError(String),

    #[error("Database error: {0}")]
    DatabaseError(String),

    #[error("Tenant validation failed")]
    TenantValidationFailed,
}

impl actix_web::ResponseError for StorageError {
    fn error_response(&self) -> HttpResponse {
        match self {
            Self::InvalidFileType(_) => HttpResponse::BadRequest().json(serde_json::json!({
                "error": self.to_string()
            })),
            Self::FileTooLarge(_, _) => HttpResponse::PayloadTooLarge().json(serde_json::json!({
                "error": self.to_string()
            })),
            _ => HttpResponse::InternalServerError().json(serde_json::json!({
                "error": "Storage operation failed"
            })),
        }
    }
}

// ============================================================================
// CONFIGURATION
// ============================================================================

const MAX_FILE_SIZE: usize = 50 * 1024 * 1024; // 50MB
const ALLOWED_IMAGE_TYPES: &[&str] = &["image/jpeg", "image/png", "image/gif", "image/webp"];
const ALLOWED_VIDEO_TYPES: &[&str] = &["video/mp4", "video/webm"];
const ALLOWED_AUDIO_TYPES: &[&str] = &["audio/mpeg", "audio/ogg", "audio/wav"];

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UploadedFile {
    pub id: String,
    pub white_label_id: String,
    pub filename: String,
    pub mime_type: String,
    pub size: usize,
    pub path: String,
    pub url: String,
    pub uploaded_at: String,
}

// ============================================================================
// FILE UPLOAD HANDLER
// ============================================================================

pub struct FileUploadHandler {
    storage_root: PathBuf,
    db: surrealdb::Surreal<surrealdb::engine::any::Any>,
}

impl FileUploadHandler {
    pub fn new(storage_root: PathBuf, db: surrealdb::Surreal<surrealdb::engine::any::Any>) -> Self {
        Self { storage_root, db }
    }

    pub async fn handle_upload(
        &self,
        white_label_id: &str,
        mut payload: Multipart,
    ) -> Result<Vec<UploadedFile>, StorageError> {
        // Validate white label exists and is active
        self.validate_tenant(white_label_id).await?;

        let mut uploaded_files = Vec::new();

        // Create upload directory for this white label
        let upload_dir = self.storage_root.join(white_label_id);
        fs::create_dir_all(&upload_dir)
            .await
            .map_err(|e| StorageError::IoError(e.to_string()))?;

        while let Some(field) = payload
            .try_next()
            .await
            .map_err(|e| StorageError::IoError(e.to_string()))?
        {
            let content_disposition = field.content_disposition();

            let filename = content_disposition
                .get_filename()
                .ok_or_else(|| StorageError::IoError("Missing filename".to_string()))?
                .to_string();

            let mime_type = field
                .content_type()
                .map(|ct| ct.to_string())
                .ok_or_else(|| StorageError::IoError("Missing content type".to_string()))?;

            // Validate file type
            self.validate_file_type(&mime_type)?;

            // Generate unique file ID and path
            let file_id = Uuid::new_v4().to_string();
            let file_extension = Path::new(&filename)
                .extension()
                .and_then(|ext| ext.to_str())
                .unwrap_or("");
            let unique_filename = format!("{}.{}", file_id, file_extension);
            let file_path = upload_dir.join(&unique_filename);

            // Stream file to disk with size check
            let mut file = std::fs::File::create(&file_path)
                .map_err(|e| StorageError::IoError(e.to_string()))?;
            let mut size = 0usize;

            let mut field_stream = field;
            while let Some(chunk) = field_stream
                .try_next()
                .await
                .map_err(|e| StorageError::IoError(e.to_string()))?
            {
                size += chunk.len();
                if size > MAX_FILE_SIZE {
                    // Clean up partial file
                    drop(file);
                    let _ = std::fs::remove_file(&file_path);
                    return Err(StorageError::FileTooLarge(size, MAX_FILE_SIZE));
                }

                file.write_all(&chunk)
                    .map_err(|e| StorageError::IoError(e.to_string()))?;
            }

            // Store metadata in SurrealDB
            let uploaded_file = UploadedFile {
                id: file_id.clone(),
                white_label_id: white_label_id.to_string(),
                filename: filename.clone(),
                mime_type: mime_type.clone(),
                size,
                path: file_path.to_string_lossy().to_string(),
                url: format!("/media/{}/{}", white_label_id, unique_filename),
                uploaded_at: chrono::Utc::now().to_rfc3339(),
            };

            self.store_metadata(&uploaded_file).await?;
            uploaded_files.push(uploaded_file);
        }

        Ok(uploaded_files)
    }

    pub async fn delete_file(&self, white_label_id: &str, file_id: &str) -> Result<(), StorageError> {
        // Validate tenant
        self.validate_tenant(white_label_id).await?;

        // Get file metadata
        let file: Option<UploadedFile> = self.db
            .select(("media", file_id))
            .await
            .map_err(|e| StorageError::DatabaseError(e.to_string()))?;

        let file = file.ok_or(StorageError::DatabaseError("File not found".to_string()))?;

        // Verify tenant ownership
        if file.white_label_id != white_label_id {
            return Err(StorageError::TenantValidationFailed);
        }

        // Delete physical file
        fs::remove_file(&file.path)
            .await
            .map_err(|e| StorageError::IoError(e.to_string()))?;

        // Delete metadata
        let _: Option<UploadedFile> = self.db
            .delete(("media", file_id))
            .await
            .map_err(|e| StorageError::DatabaseError(e.to_string()))?;

        Ok(())
    }

    pub async fn list_files(&self, white_label_id: &str) -> Result<Vec<UploadedFile>, StorageError> {
        // Validate tenant
        self.validate_tenant(white_label_id).await?;

        let files: Vec<UploadedFile> = self.db
            .query("SELECT * FROM media WHERE white_label_id = $wl_id ORDER BY uploaded_at DESC")
            .bind(("wl_id", white_label_id))
            .await
            .map_err(|e| StorageError::DatabaseError(e.to_string()))?
            .take(0)
            .map_err(|e| StorageError::DatabaseError(e.to_string()))?;

        Ok(files)
    }

    // ========================================================================
    // PRIVATE HELPERS
    // ========================================================================

    fn validate_file_type(&self, mime_type: &str) -> Result<(), StorageError> {
        let allowed = ALLOWED_IMAGE_TYPES
            .iter()
            .chain(ALLOWED_VIDEO_TYPES.iter())
            .chain(ALLOWED_AUDIO_TYPES.iter())
            .any(|&allowed_type| mime_type == allowed_type);

        if allowed {
            Ok(())
        } else {
            Err(StorageError::InvalidFileType(mime_type.to_string()))
        }
    }

    async fn validate_tenant(&self, white_label_id: &str) -> Result<(), StorageError> {
        let exists: Option<serde_json::Value> = self.db
            .select(("white_labels", white_label_id))
            .await
            .map_err(|e| StorageError::DatabaseError(e.to_string()))?;

        if exists.is_some() {
            Ok(())
        } else {
            Err(StorageError::TenantValidationFailed)
        }
    }

    async fn store_metadata(&self, file: &UploadedFile) -> Result<(), StorageError> {
        let _: Option<UploadedFile> = self.db
            .create(("media", &file.id))
            .content(file)
            .await
            .map_err(|e| StorageError::DatabaseError(e.to_string()))?;

        Ok(())
    }
}

// ============================================================================
// ACTIX-WEB ROUTES
// ============================================================================

#[derive(Clone)]
pub struct StorageState {
    pub handler: std::sync::Arc<FileUploadHandler>,
}

pub async fn upload_files(
    white_label_id: web::Path<String>,
    payload: Multipart,
    state: web::Data<StorageState>,
) -> Result<HttpResponse, Error> {
    let files = state.handler.handle_upload(&white_label_id, payload).await?;
    Ok(HttpResponse::Ok().json(files))
}

pub async fn delete_file(
    path: web::Path<(String, String)>,
    state: web::Data<StorageState>,
) -> Result<HttpResponse, Error> {
    let (white_label_id, file_id) = path.into_inner();
    state.handler.delete_file(&white_label_id, &file_id).await?;
    Ok(HttpResponse::NoContent().finish())
}

pub async fn list_files(
    white_label_id: web::Path<String>,
    state: web::Data<StorageState>,
) -> Result<HttpResponse, Error> {
    let files = state.handler.list_files(&white_label_id).await?;
    Ok(HttpResponse::Ok().json(files))
}

// ============================================================================
// CONFIGURATION
// ============================================================================

pub fn configure_routes(cfg: &mut web::ServiceConfig) {
    cfg.service(
        web::scope("/api/v1")
            .route("/media/{white_label_id}", web::post().to(upload_files))
            .route("/media/{white_label_id}", web::get().to(list_files))
            .route("/media/{white_label_id}/{file_id}", web::delete().to(delete_file))
    );
}