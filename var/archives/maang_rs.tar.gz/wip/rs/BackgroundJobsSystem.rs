// crates/infrastructure/jobs/src/lib.rs
//! Background job processing with SurrealDB queue

use serde::{Deserialize, Serialize};
use std::sync::Arc;
use std::time::Duration;
use thiserror::Error;
use tokio::sync::RwLock;
use tokio::time;
use tracing::{error, info, warn};

#[derive(Error, Debug)]
pub enum JobError {
    #[error("Database error: {0}")]
    DatabaseError(String),

    #[error("Job execution failed: {0}")]
    ExecutionFailed(String),

    #[error("Job not found: {0}")]
    NotFound(String),

    #[error("Max retries exceeded")]
    MaxRetriesExceeded,
}

// ============================================================================
// JOB TYPES
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", content = "data")]
pub enum JobType {
    // Email jobs
    SendWelcomeEmail { user_id: String, email: String },
    SendInvoiceEmail { invoice_id: String, tenant_id: String },
    SendPasswordReset { user_id: String, token: String },

    // Stripe jobs
    ProcessStripeWebhook { event_id: String, event_type: String },
    SyncSubscription { subscription_id: String },
    GenerateInvoice { tenant_id: String, period_start: String },

    // Tenant jobs
    ProvisionTenant { tenant_id: String, plan: String },
    DeleteTenant { tenant_id: String },
    BackupTenantData { tenant_id: String },

    // Maintenance jobs
    CleanupExpiredSessions,
    RotateLogs,
    GenerateAnalytics { date: String },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Job {
    pub id: String,
    pub job_type: JobType,
    pub status: JobStatus,
    pub priority: i32,
    pub attempts: u32,
    pub max_attempts: u32,
    pub created_at: String,
    pub scheduled_at: Option<String>,
    pub started_at: Option<String>,
    pub completed_at: Option<String>,
    pub error: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "lowercase")]
pub enum JobStatus {
    Pending,
    Running,
    Completed,
    Failed,
    Cancelled,
}

// ============================================================================
// JOB QUEUE
// ============================================================================

pub struct JobQueue {
    db: surrealdb::Surreal<surrealdb::engine::any::Any>,
    workers: usize,
    shutdown: Arc<RwLock<bool>>,
}

impl JobQueue {
    pub fn new(db: surrealdb::Surreal<surrealdb::engine::any::Any>, workers: usize) -> Self {
        Self {
            db,
            workers,
            shutdown: Arc::new(RwLock::new(false)),
        }
    }

    pub async fn enqueue(&self, job_type: JobType, priority: i32) -> Result<String, JobError> {
        self.enqueue_scheduled(job_type, priority, None).await
    }

    pub async fn enqueue_scheduled(
        &self,
        job_type: JobType,
        priority: i32,
        scheduled_at: Option<String>,
    ) -> Result<String, JobError> {
        let job = Job {
            id: uuid::Uuid::new_v4().to_string(),
            job_type,
            status: JobStatus::Pending,
            priority,
            attempts: 0,
            max_attempts: 3,
            created_at: chrono::Utc::now().to_rfc3339(),
            scheduled_at,
            started_at: None,
            completed_at: None,
            error: None,
        };

        let _: Option<Job> = self.db
            .create(("jobs", &job.id))
            .content(&job)
            .await
            .map_err(|e| JobError::DatabaseError(e.to_string()))?;

        info!("Enqueued job: {} with priority {}", job.id, priority);
        Ok(job.id)
    }

    pub async fn start(&self) {
        info!("Starting job queue with {} workers", self.workers);

        let mut handles = Vec::new();

        for worker_id in 0..self.workers {
            let db = self.db.clone();
            let shutdown = Arc::clone(&self.shutdown);

            let handle = tokio::spawn(async move {
                Self::worker_loop(worker_id, db, shutdown).await;
            });

            handles.push(handle);
        }

        // Wait for all workers to finish
        for handle in handles {
            let _ = handle.await;
        }
    }

    pub async fn shutdown(&self) {
        info!("Shutting down job queue");
        let mut shutdown = self.shutdown.write().await;
        *shutdown = true;
    }

    async fn worker_loop(
        worker_id: usize,
        db: surrealdb::Surreal<surrealdb::engine::any::Any>,
        shutdown: Arc<RwLock<bool>>,
    ) {
        info!("Worker {} started", worker_id);

        loop {
            // Check shutdown signal
            if *shutdown.read().await {
                info!("Worker {} shutting down", worker_id);
                break;
            }

            // Fetch next job
            match Self::fetch_next_job(&db).await {
                Ok(Some(job)) => {
                    info!("Worker {} processing job {}", worker_id, job.id);

                    // Process job
                    let result = Self::process_job(&db, job.clone()).await;

                    match result {
                        Ok(_) => {
                            info!("Worker {} completed job {}", worker_id, job.id);
                        }
                        Err(e) => {
                            error!("Worker {} failed job {}: {}", worker_id, job.id, e);
                        }
                    }
                }
                Ok(None) => {
                    // No jobs available, sleep
                    time::sleep(Duration::from_secs(1)).await;
                }
                Err(e) => {
                    error!("Worker {} error fetching job: {}", worker_id, e);
                    time::sleep(Duration::from_secs(5)).await;
                }
            }
        }
    }

    async fn fetch_next_job(
        db: &surrealdb::Surreal<surrealdb::engine::any::Any>,
    ) -> Result<Option<Job>, JobError> {
        // Query for pending jobs, prioritized by priority and created_at
        let mut result: Vec<Job> = db
            .query(r#"
                SELECT * FROM jobs
                WHERE status = 'pending'
                AND (scheduled_at IS NONE OR scheduled_at <= time::now())
                ORDER BY priority DESC, created_at ASC
                LIMIT 1
            "#)
            .await
            .map_err(|e| JobError::DatabaseError(e.to_string()))?
            .take(0)
            .map_err(|e| JobError::DatabaseError(e.to_string()))?;

        if let Some(mut job) = result.pop() {
            // Mark as running
            job.status = JobStatus::Running;
            job.started_at = Some(chrono::Utc::now().to_rfc3339());
            job.attempts += 1;

            let _: Option<Job> = db
                .update(("jobs", &job.id))
                .content(&job)
                .await
                .map_err(|e| JobError::DatabaseError(e.to_string()))?;

            Ok(Some(job))
        } else {
            Ok(None)
        }
    }

    async fn process_job(
        db: &surrealdb::Surreal<surrealdb::engine::any::Any>,
        mut job: Job,
    ) -> Result<(), JobError> {
        // Execute job based on type
        let result = Self::execute_job(&job.job_type).await;

        match result {
            Ok(_) => {
                job.status = JobStatus::Completed;
                job.completed_at = Some(chrono::Utc::now().to_rfc3339());
            }
            Err(e) => {
                job.error = Some(e.to_string());

                if job.attempts >= job.max_attempts {
                    job.status = JobStatus::Failed;
                    error!("Job {} failed after {} attempts", job.id, job.attempts);
                } else {
                    job.status = JobStatus::Pending;
                    warn!("Job {} failed, will retry (attempt {}/{})", 
                          job.id, job.attempts, job.max_attempts);
                }
            }
        }

        let _: Option<Job> = db
            .update(("jobs", &job.id))
            .content(&job)
            .await
            .map_err(|e| JobError::DatabaseError(e.to_string()))?;

        Ok(())
    }

    async fn execute_job(job_type: &JobType) -> Result<(), JobError> {
        match job_type {
            JobType::SendWelcomeEmail { user_id, email } => {
                // TODO: Implement email sending
                info!("Sending welcome email to {} (user: {})", email, user_id);
                time::sleep(Duration::from_millis(100)).await; // Simulate work
                Ok(())
            }

            JobType::SendInvoiceEmail { invoice_id, tenant_id } => {
                info!("Sending invoice {} to tenant {}", invoice_id, tenant_id);
                time::sleep(Duration::from_millis(100)).await;
                Ok(())
            }

            JobType::SendPasswordReset { user_id, token } => {
                info!("Sending password reset to user {} (token: {})", user_id, token);
                time::sleep(Duration::from_millis(100)).await;
                Ok(())
            }

            JobType::ProcessStripeWebhook { event_id, event_type } => {
                info!("Processing Stripe webhook: {} ({})", event_id, event_type);
                time::sleep(Duration::from_millis(200)).await;
                Ok(())
            }

            JobType::SyncSubscription { subscription_id } => {
                info!("Syncing subscription: {}", subscription_id);
                time::sleep(Duration::from_millis(150)).await;
                Ok(())
            }

            JobType::GenerateInvoice { tenant_id, period_start } => {
                info!("Generating invoice for tenant {} (period: {})", tenant_id, period_start);
                time::sleep(Duration::from_millis(300)).await;
                Ok(())
            }

            JobType::ProvisionTenant { tenant_id, plan } => {
                info!("Provisioning tenant {} with plan {}", tenant_id, plan);
                time::sleep(Duration::from_millis(500)).await;
                Ok(())
            }

            JobType::DeleteTenant { tenant_id } => {
                info!("Deleting tenant {}", tenant_id);
                time::sleep(Duration::from_millis(400)).await;
                Ok(())
            }

            JobType::BackupTenantData { tenant_id } => {
                info!("Backing up tenant data: {}", tenant_id);
                time::sleep(Duration::from_millis(1000)).await;
                Ok(())
            }

            JobType::CleanupExpiredSessions => {
                info!("Cleaning up expired sessions");
                time::sleep(Duration::from_millis(200)).await;
                Ok(())
            }

            JobType::RotateLogs => {
                info!("Rotating logs");
                time::sleep(Duration::from_millis(100)).await;
                Ok(())
            }

            JobType::GenerateAnalytics { date } => {
                info!("Generating analytics for {}", date);
                time::sleep(Duration::from_millis(600)).await;
                Ok(())
            }
        }
    }

    pub async fn get_stats(&self) -> Result<JobStats, JobError> {
        let pending: Vec<Job> = self.db
            .query("SELECT * FROM jobs WHERE status = 'pending'")
            .await
            .map_err(|e| JobError::DatabaseError(e.to_string()))?
            .take(0)
            .map_err(|e| JobError::DatabaseError(e.to_string()))?;

        let running: Vec<Job> = self.db
            .query("SELECT * FROM jobs WHERE status = 'running'")
            .await
            .map_err(|e| JobError::DatabaseError(e.to_string()))?
            .take(0)
            .map_err(|e| JobError::DatabaseError(e.to_string()))?;

        let failed: Vec<Job> = self.db
            .query("SELECT * FROM jobs WHERE status = 'failed'")
            .await
            .map_err(|e| JobError::DatabaseError(e.to_string()))?
            .take(0)
            .map_err(|e| JobError::DatabaseError(e.to_string()))?;

        Ok(JobStats {
            pending: pending.len(),
            running: running.len(),
            failed: failed.len(),
        })
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct JobStats {
    pub pending: usize,
    pub running: usize,
    pub failed: usize,
}