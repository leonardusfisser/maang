// crates/core/config/src/app_config.rs
use std::{env as os_env, path::Path};
use core_errors::EnvError;
use crate::types::SiteInfo;

pub fn load_env(app_name: &str) -> Result<(), EnvError> {
    if let Ok(custom) = os_env::var("ENV_FILE") {
        return load_from(&custom);
    }

    let app_dotenv = format!("apps/{}/.env", app_name);
    if Path::new(&app_dotenv).exists() {
        return load_from(&app_dotenv);
    }

    if Path::new(".env").exists() {
        return load_from(".env");
    }

    Ok(())
}

fn load_from(path: &str) -> Result<(), EnvError> {
    dotenvy::from_path(Path::new(path))
        .map_err(|e| EnvError::Load { path: path.to_string(), source: Box::new(e) })
}

/// Build `SiteInfo` with **safe defaults** (good for dev).
pub fn load_site_info_with_defaults() -> SiteInfo {
    SiteInfo {
        site_name:  os_env::var("SITE_NAME").unwrap_or_else(|_| "Unnamed App".to_string()),
        site_title: os_env::var("SITE_TITLE").unwrap_or_else(|_| "Unnamed CMS".to_string()),
        tagline:    os_env::var("SITE_TAGLINE").unwrap_or_else(|_| "Powered by Maangframe".to_string()),
    }
}

/// Strict version: require specific vars (good for prod checks).
pub fn load_site_info_required() -> Result<SiteInfo, EnvError> {
    Ok(SiteInfo {
        site_name:  must("SITE_NAME")?,
        site_title: must("SITE_TITLE")?,
        // tagline can be optional with a default:
        tagline:    os_env::var("SITE_TAGLINE").unwrap_or_else(|_| "Powered by Maangframe".to_string()),
    })
}

/// Return "HOST:PORT" with **safe defaults**.
pub fn host_port_with_defaults() -> String {
    let host = os_env::var("HOST").unwrap_or_else(|_| "127.0.0.1".to_string());
    let port = os_env::var("PORT").unwrap_or_else(|_| "8080".to_string());
    format!("{host}:{port}")
}

/// Strict version: require HOST and a valid u16 PORT.
pub fn host_port_required() -> Result<String, EnvError> {
    let host = must("HOST")?;
    let port_str = must("PORT")?;
    let port: u16 = match port_str.parse() {
        Ok(p) => p,
        Err(e) => {
            return Err(EnvError::Load {
                path: "PORT".to_string(),
                source: Box::new(e),
            })
        }
    };
    Ok(format!("{host}:{port}"))
}

fn must(key: &str) -> Result<String, EnvError> {
    os_env::var(key).map_err(|_| EnvError::MissingVar(key.to_string()))
}
