#[derive(Debug, Clone, serde::Deserialize)]
pub struct SiteInfo {
    pub site_name: String,
    pub site_title: String,
    pub tagline: String,
}
