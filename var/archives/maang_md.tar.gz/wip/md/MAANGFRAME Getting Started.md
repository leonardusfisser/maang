# MAANGFRAME - Getting Started Guide

## 🚀 5-Minute Quick Start

### Prerequisites Check
```bash
# Check Rust
rustc --version  # Should be 1.70+

# If not installed:
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

### 1. Install Dependencies (One-Time Setup)

**On Parrot OS (Dev - MP80):**
```bash
# System packages
sudo apt update
sudo apt install -y redis-server build-essential pkg-config libssl-dev

# SurrealDB
curl -sSf https://install.surrealdb.com | sh

# Start services
sudo systemctl start redis-server
surreal start --bind 0.0.0.0:8000 &
```

**On Debian (Production - MP100):**
```bash
# Run production setup script
./production/setup.sh

# This installs:
# - Redis, SurrealDB, Nginx, Certbot, Netdata
# - Creates lillpepe user
# - Sets up directories
# - Configures systemd services
```

---

### 2. Clone & Configure

```bash
# Navigate to your project
cd /path/to/maangframe

# Create environment file
cat > .env <<'EOF'
# Database
DATABASE_URL=ws://localhost:8000
DATABASE_NAMESPACE=lillpepe
DATABASE_NAME=main
MIGRATIONS_DIR=./migrations

# Redis
REDIS_URL=redis://localhost:6379
SESSION_TTL=86400

# Jobs
JOB_WORKERS=4

# Email (Update with your credentials)
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_USERNAME=apikey
SMTP_PASSWORD=YOUR_SENDGRID_API_KEY
FROM_EMAIL=noreply@lillpepe.com
FROM_NAME=Lillpepe

# Logging
RUST_LOG=info,lillpepe=debug
EOF
```

---

### 3. Initialize Database

```bash
# Build migration tool
cargo build --bin migrate

# Initialize migrations table
cargo run --bin migrate init

# Run migrations
cargo run --bin migrate run

# Verify
cargo run --bin migrate status
```

Expected output:
```
╔══════════════════════════════════════╗
║     Migration Status                 ║
╠══════════════════════════════════════╣
║  Total:   3                          ║
║  Applied: 3                          ║
║  Pending: 0                          ║
╚══════════════════════════════════════╝
```

---

### 4. Build & Run

**Development Mode:**
```bash
# Build and run
cargo run --bin lillpepe

# Or with auto-reload (install cargo-watch first)
cargo install cargo-watch
cargo watch -x 'run --bin lillpepe'
```

**Production Mode:**
```bash
# Build optimized binary
cargo build --release

# Binary location
./target/release/lillpepe

# Or deploy to production
./tools/deploy.fish
```

---

### 5. Verify Installation

**Health Check:**
```bash
curl http://localhost:8080/api/v1/health
```

Expected response:
```json
{
  "status": "healthy",
  "timestamp": "2025-10-20T...",
  "version": "0.1.0",
  "jobs": {
    "pending": 0,
    "running": 0,
    "failed": 0
  },
  "sessions": {
    "active": 0
  }
}
```

**Test Endpoints:**
```bash
# Home page
curl http://localhost:8080/

# Admin dashboard
curl http://localhost:8080/admin

# API routes
curl http://localhost:8080/api/v1/products
```

---

## 🧪 Test the Framework

### 1. Create a Test User (Onboarding Flow)

```bash
# Start onboarding
curl -X POST http://localhost:8080/api/v1/onboarding/start \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "name": "Test User"
  }'

# Response: {"user_id":"...", "next_step":"email_verification"}
```

### 2. Check Job Queue

```bash
# Job stats
curl http://localhost:8080/api/v1/jobs/stats

# Or via healthcheck tool
cargo run --bin healthcheck -- watch
```

### 3. Test Email System

```bash
# Trigger password reset (sends email)
curl -X POST http://localhost:8080/api/v1/auth/password-reset \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com"}'

# Check logs to see email job
journalctl -u lillpepe -f | grep "Sending password reset"
```

### 4. View Admin Dashboard

```bash
# Open in browser
xdg-open http://localhost:8080/admin

# Or check via curl
curl http://localhost:8080/admin/tenants
```

---

## 📊 Monitoring

### Check All Services

```bash
# SurrealDB
curl http://localhost:8000/health

# Redis
redis-cli ping

# Lillpepe
curl http://localhost:8080/api/v1/health

# Netdata (if installed)
xdg-open http://localhost:19999
```

### View Logs

```bash
# Application logs
journalctl -u lillpepe -f

# Follow specific patterns
journalctl -u lillpepe -f | grep ERROR
journalctl -u lillpepe -f | grep "Job"
journalctl -u lillpepe -f | grep "Email"
```

### Check Resources

```bash
# Memory usage
ps aux | grep lillpepe

# Database size
du -sh /opt/lillpepe/storage/

# Redis info
redis-cli info memory
```

---

## 🔧 Development Workflow

### 1. Create New Migration

```bash
cargo run --bin migrate create add_blog_posts

# Edit: migrations/004_add_blog_posts.surql
# Then run:
cargo run --bin migrate run
```

### 2. Add New Job Type

Edit `crates/infrastructure/jobs/src/lib.rs`:
```rust
pub enum JobType {
    // ... existing types
    SendNewsletter { user_ids: Vec<String> },
}
```

Implement in `execute_job`:
```rust
JobType::SendNewsletter { user_ids } => {
    info!("Sending newsletter to {} users", user_ids.len());
    // Implementation
    Ok(())
}
```

### 3. Add New API Endpoint

Edit `apps/lillpepe/src/routes.rs`:
```rust
.route("/api/v1/my-endpoint", web::get().to(my_handler))
```

Add handler:
```rust
async fn my_handler(state: web::Data<AppState>) -> HttpResponse {
    HttpResponse::Ok().json(serde_json::json!({
        "message": "Hello from my endpoint"
    }))
}
```

### 4. Run Tests

```bash
# All tests
cargo test

# Specific package
cargo test --package infrastructure-jobs

# With output
cargo test -- --nocapture

# Integration tests
cargo test --test integration
```

---

## 🚀 Deploy to Production

### First-Time Setup

```bash
# On production server (MP100)
git clone <your-repo>
cd maangframe

# Run production setup
sudo ./production/setup.sh

# Update SMTP credentials
sudo nano /opt/lillpepe/.env

# Build release binary locally
cargo build --release

# Deploy
./tools/deploy.fish
```

### Subsequent Deploys

```bash
# Build
cargo build --release

# Deploy (with health checks & rollback)
./tools/deploy.fish
```

### Monitor Deployment

```bash
# SSH to server
ssh lillpepe@production.lillpepe.com

# Check service
sudo systemctl status lillpepe

# View logs
journalctl -u lillpepe -f

# Health check
curl http://localhost:8080/api/v1/health
```

---

## 🐛 Troubleshooting

### Issue: SurrealDB not starting

```bash
# Check if running
ps aux | grep surreal

# Start manually
surreal start --bind 0.0.0.0:8000

# Check logs
journalctl -u surrealdb -f
```

### Issue: Redis connection failed

```bash
# Check Redis
redis-cli ping

# Start Redis
sudo systemctl start redis-server

# Check connection
redis-cli -h 127.0.0.1 -p 6379
```

### Issue: Migrations failing

```bash
# Check migration syntax
cat migrations/001_initial_schema.surql

# Reset and retry
cargo run --bin migrate rollback
cargo run --bin migrate run
```

### Issue: Jobs not processing

```bash
# Check worker count
echo $JOB_WORKERS

# Check job stats
curl http://localhost:8080/api/v1/jobs/stats

# View job queue in database
surreal sql --conn http://localhost:8000 --user root --pass root --ns lillpepe --db main
> SELECT * FROM jobs WHERE status = 'failed';
```

---

## 📚 Next Steps

### Build Your First App Feature

1. **Define domain model** in `crates/domain/`
2. **Create migration** for new tables
3. **Add API routes** in `apps/lillpepe/src/routes.rs`
4. **Add templates** in `templates/`
5. **Test locally** with `cargo run`
6. **Deploy** with `./tools/deploy.fish`

### Example: Add Blog Posts

```bash
# 1. Create migration
cargo run --bin migrate create add_blog_posts

# 2. Edit migration (see migrations folder)

# 3. Run migration
cargo run --bin migrate run

# 4. Add API routes (see routes.rs)

# 5. Test
curl -X POST http://localhost:8080/api/v1/posts \
  -H "Content-Type: application/json" \
  -d '{"title":"My Post","content":"Hello!"}'

# 6. Deploy
cargo build --release && ./tools/deploy.fish
```

---

## 🎉 You're Ready!

**Framework is 100% complete. Start building your apps!**

**Key Resources:**
- Health: `http://localhost:8080/api/v1/health`
- Admin: `http://localhost:8080/admin`
- Logs: `journalctl -u lillpepe -f`
- Monitoring: `http://localhost:19999`

**Questions?** Check the logs first. Most issues show up there.

**Happy building! 🚀**