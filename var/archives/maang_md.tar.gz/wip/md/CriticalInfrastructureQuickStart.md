# Critical Infrastructure - Complete ✅

## What We Built

### 1. Background Jobs System
**Purpose**: Async task processing for webhooks, emails, maintenance

**Features**:
- SurrealDB-backed job queue
- Multiple workers (configurable)
- Priority-based execution
- Automatic retries (max 3 attempts)
- Scheduled jobs support
- Job status tracking

**Job Types**:
- Email: Welcome, invoice, password reset
- Stripe: Webhook processing, subscription sync
- Tenant: Provision, delete, backup
- Maintenance: Session cleanup, log rotation, analytics

### 2. Database Migrations
**Purpose**: Version control for database schema

**Features**:
- Sequential versioning (001, 002, 003...)
- Checksum validation
- Applied migration tracking
- Rollback support
- CLI tool for management

**Commands**:
```bash
migrate init          # Initialize migrations table
migrate run           # Apply pending migrations
migrate status        # Show migration status
migrate rollback      # Remove last migration record
migrate create <n>  # Create new migration file
```

### 3. Redis Session Management
**Purpose**: Secure, scalable user sessions

**Features**:
- Redis-backed storage
- Configurable TTL (default: 24 hours)
- Automatic refresh on activity
- User role support (Admin, Tenant, User)
- Tenant isolation
- Bulk session management (destroy all user sessions)
- Activity tracking (IP, user agent, timestamps)

---

## 🚀 Quick Start

### Prerequisites
```bash
# Install Redis
sudo apt install redis-server
sudo systemctl start redis

# Install SurrealDB
curl -sSf https://install.surrealdb.com | sh
surreal start --bind 0.0.0.0:8000
```

### Setup

**1. Add to Cargo.toml workspace**:
```toml
[workspace]
members = [
    # ... existing members
    "crates/infrastructure/jobs",
    "crates/infrastructure/migrations",
    "crates/infrastructure/sessions",
    "tools/migrate",
]
```

**2. Create migrations directory**:
```bash
mkdir -p migrations
```

**3. Add initial migrations** (already provided in artifacts)

**4. Run migrations**:
```bash
cargo run --bin migrate init
cargo run --bin migrate run
```

**5. Start application** with all three systems integrated

---

## 📖 Usage Examples

### Background Jobs

**Enqueue a job**:
```rust
use infrastructure_jobs::{JobQueue, JobType};

let mut job_queue = JobQueue::new(db, 4); // 4 workers

// Enqueue email job
job_queue.enqueue(
    JobType::SendWelcomeEmail {
        user_id: "user_123".to_string(),
        email: "user@example.com".to_string(),
    },
    10, // priority
).await?;

// Enqueue scheduled job (1 hour from now)
let scheduled_time = chrono::Utc::now() + chrono::Duration::hours(1);
job_queue.enqueue_scheduled(
    JobType::BackupTenantData {
        tenant_id: "tenant_456".to_string(),
    },
    50,
    Some(scheduled_time.to_rfc3339()),
).await?;
```

**Start job workers**:
```rust
let job_queue = Arc::new(RwLock::new(job_queue));
let queue_clone = Arc::clone(&job_queue);

tokio::spawn(async move {
    let queue = queue_clone.read().await;
    queue.start().await;
});
```

**Check job stats**:
```rust
let stats = job_queue.get_stats().await?;
println!("Pending: {}, Running: {}, Failed: {}",
    stats.pending, stats.running, stats.failed);
```

### Database Migrations

**Create new migration**:
```bash
migrate create add_blog_posts_table
# Creates: migrations/004_add_blog_posts_table.surql
```

**Edit migration file**:
```sql
-- migrations/004_add_blog_posts_table.surql
DEFINE TABLE blog_posts SCHEMAFULL;
DEFINE FIELD id ON blog_posts TYPE string;
DEFINE FIELD white_label_id ON blog_posts TYPE string;
DEFINE FIELD title ON blog_posts TYPE string;
DEFINE FIELD content ON blog_posts TYPE string;
DEFINE FIELD published_at ON blog_posts TYPE datetime;
DEFINE INDEX idx_posts_white_label ON blog_posts FIELDS white_label_id;
```

**Apply migration**:
```bash
migrate run
```

**Check status**:
```bash
migrate status
```

### Session Management

**Create session (login)**:
```rust
use infrastructure_sessions::{SessionManager, UserRole};

let mut session_manager = SessionManager::new("redis://localhost:6379", 86400).await?;

let session_id = session_manager.create_session(
    "user_123".to_string(),
    Some("tenant_456".to_string()),
    "user@example.com".to_string(),
    UserRole::User,
    req.connection_info().peer_addr().unwrap_or("unknown").to_string(),
    req.headers().get("user-agent").map(|v| v.to_str().unwrap_or("")).unwrap_or("").to_string(),
).await?;
```

**Validate session (middleware)**:
```rust
let session_data = session_manager.get_session(&session_id).await?;

// Check user role
if session_data.role != UserRole::Admin {
    return Err(actix_web::error::ErrorForbidden("Admin access required"));
}

// Check tenant access
if let Some(tenant_id) = &session_data.tenant_id {
    if tenant_id != &requested_tenant_id {
        return Err(actix_web::error::ErrorForbidden("Access denied"));
    }
}
```

**Destroy session (logout)**:
```rust
session_manager.destroy_session(&session_id).await?;
```

**Destroy all user sessions (password reset)**:
```rust
let count = session_manager.destroy_user_sessions(&user_id).await?;
println!("Destroyed {} sessions for user", count);
```

---

## 🏗️ Integration Pattern

**main.rs structure**:
```rust
#[actix_web::main]
async fn main() -> std::io::Result<()> {
    // 1. Connect to SurrealDB
    let db = connect_db().await;
    
    // 2. Run migrations
    let migration_manager = MigrationManager::new(db.clone(), "migrations".to_string());
    migration_manager.init().await.expect("Migration init failed");
    migration_manager.run_pending().await.expect("Migrations failed");
    
    // 3. Initialize job queue
    let job_queue = Arc::new(RwLock::new(JobQueue::new(db.clone(), 4)));
    tokio::spawn({
        let queue = Arc::clone(&job_queue);
        async move {
            queue.read().await.start().await;
        }
    });
    
    // 4. Initialize session manager
    let session_manager = SessionManager::new("redis://localhost:6379", 86400).await?;
    let session_manager = Arc::new(RwLock::new(session_manager));
    
    // 5. Create app state
    let app_state = AppState {
        db,
        job_queue,
        session_manager,
    };
    
    // 6. Start HTTP server
    HttpServer::new(move || {
        App::new()
            .app_data(web::Data::new(app_state.clone()))
            .configure(routes)
    })
    .bind(("0.0.0.0", 8080))?
    .run()
    .await
}
```

---

## 🧪 Testing

### Test Background Jobs
```bash
# Start SurrealDB
surreal start --bind 0.0.0.0:8000

# Run tests
cargo test --package infrastructure-jobs
```

### Test Migrations
```bash
# Initialize test database
export DATABASE_NAMESPACE=test_lillpepe
export DATABASE_NAME=test

# Run migration tests
migrate init
migrate run
migrate status
migrate rollback
```

### Test Sessions
```bash
# Start Redis
redis-server

# Run session tests
cargo test --package infrastructure-sessions
```

---

## 📊 Monitoring

### Job Queue Stats Endpoint
```rust
#[get("/api/v1/jobs/stats")]
async fn job_stats(state: web::Data<AppState>) -> HttpResponse {
    let queue = state.job_queue.read().await;
    let stats = queue.get_stats().await.unwrap();
    HttpResponse::Ok().json(stats)
}
```

### Active Sessions Endpoint
```rust
#[get("/api/v1/sessions/active")]
async fn active_sessions(state: web::Data<AppState>) -> HttpResponse {
    let manager = state.session_manager.read().await;
    let sessions = manager.get_active_sessions().await.unwrap();
    HttpResponse::Ok().json(serde_json::json!({
        "count": sessions.len(),
        "sessions": sessions,
    }))
}
```

### Migration Status Endpoint
```rust
#[get("/api/v1/migrations/status")]
async fn migration_status(state: web::Data<AppState>) -> HttpResponse {
    let manager = MigrationManager::new(state.db.clone(), "migrations".to_string());
    let status = manager.status().await.unwrap();
    HttpResponse::Ok().json(status)
}
```

---

## ✅ Production Checklist

### Background Jobs
- [ ] Workers configured (recommend: 4-8 for production)
- [ ] Job retry logic tested
- [ ] Failed job alerting configured
- [ ] Job stats monitored in Netdata

### Migrations
- [ ] All migrations tested in staging
- [ ] Rollback procedure documented
- [ ] Automated migration on deploy
- [ ] Migration status checked before app start

### Sessions
- [ ] Redis persistent storage configured
- [ ] Session TTL appropriate for use case
- [ ] Cleanup job scheduled (CleanupExpiredSessions)
- [ ] Active session monitoring
- [ ] Session security headers set (HttpOnly, Secure, SameSite)

---

## 🎯 Next Steps

You now have the **critical infrastructure** for MAANGFRAME:

✅ Background jobs for async tasks  
✅ Database migrations for schema versioning  
✅ Redis sessions for secure auth

**Ready to build on top:**
- Email system (uses job queue)
- Tenant onboarding (uses jobs + migrations)
- Subscription management (uses jobs + sessions)
- Audit logging (uses sessions + jobs)

**The foundation is solid. Time to build the business logic layer.**