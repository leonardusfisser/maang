# Lillpepe Production Deployment Checklist

## 📋 Pre-Deployment

### Infrastructure Setup
- [ ] Server provisioned (MP100 Debian)
- [ ] DNS configured and propagating
- [ ] SSH access configured with key-based auth
- [ ] Firewall rules configured (22, 80, 443)
- [ ] Domain purchased and configured

### Dependencies Installed
- [ ] Rust toolchain installed
- [ ] SurrealDB installed and running
- [ ] Redis installed and running
- [ ] Nginx installed and configured
- [ ] Certbot installed for SSL
- [ ] Netdata installed for monitoring

### Application Setup
- [ ] Lillpepe user created
- [ ] Directories created (`/opt/lillpepe`, `/var/log/lillpepe`, `/var/backups/lillpepe`)
- [ ] Environment variables configured (`.env` file)
- [ ] SMTP credentials added
- [ ] Permissions set correctly

---

## 🔧 Configuration

### Database
- [ ] SurrealDB systemd service configured
- [ ] SurrealDB bound to localhost only
- [ ] Database credentials secured
- [ ] Migrations folder copied
- [ ] Initial migrations ready

### Redis
- [ ] Redis systemd service enabled
- [ ] Redis bound to localhost only
- [ ] Persistence configured (AOF + RDB)
- [ ] Memory limit set appropriately

### Nginx
- [ ] Nginx configuration file created
- [ ] Static file paths configured
- [ ] Proxy settings optimized
- [ ] SSL certificate obtained (Let's Encrypt)
- [ ] Security headers added
- [ ] Gzip compression enabled

### Systemd Services
- [ ] `surrealdb.service` configured
- [ ] `lillpepe.service` configured
- [ ] Resource limits set (2GB RAM, 80% CPU)
- [ ] Restart policy configured
- [ ] Logging to journald configured

### Cron Jobs
- [ ] Health checks (every 5 minutes)
- [ ] Daily backups (2 AM)
- [ ] Weekly backup cleanup
- [ ] Monthly log rotation
- [ ] Disk space monitoring

---

## 🏗️ Application Build

### Compilation
- [ ] Debug build tested locally: `cargo build`
- [ ] Release build created: `cargo build --release`
- [ ] Binary size optimized (LTO enabled)
- [ ] All tests passing: `cargo test`
- [ ] Clippy warnings addressed: `cargo clippy`

### Migrations
- [ ] All migration files in `migrations/` folder
- [ ] Migration syntax validated
- [ ] Test migrations run on staging database
- [ ] Rollback procedures documented

---

## 🚀 Deployment

### Initial Deployment
- [ ] Run production setup script: `./production/setup.sh`
- [ ] Binary uploaded to server
- [ ] Migrations directory synced
- [ ] Static files synced
- [ ] Templates synced
- [ ] Permissions verified

### Database Initialization
- [ ] Run `migrate init`
- [ ] Run `migrate run`
- [ ] Verify migrations: `migrate status`
- [ ] Create initial admin user
- [ ] Seed sample data (if needed)

### Service Startup
- [ ] Start SurrealDB: `sudo systemctl start surrealdb`
- [ ] Start Redis: `sudo systemctl start redis-server`
- [ ] Start Lillpepe: `sudo systemctl start lillpepe`
- [ ] Start Nginx: `sudo systemctl start nginx`
- [ ] Enable services on boot: `systemctl enable <service>`

### Health Checks
- [ ] SurrealDB responding: `curl http://localhost:8000/health`
- [ ] Redis responding: `redis-cli ping`
- [ ] Lillpepe responding: `curl http://localhost:8080/api/v1/health`
- [ ] Nginx serving requests: `curl http://localhost`
- [ ] SSL certificate valid: `openssl s_client -connect lillpepe.com:443`

---

## 🔐 Security

### SSL/TLS
- [ ] SSL certificate installed (Let's Encrypt)
- [ ] Auto-renewal configured (certbot)
- [ ] HTTPS redirect configured
- [ ] HSTS header enabled
- [ ] Certificate expiry monitored

### Application Security
- [ ] Rate limiting enabled (100 req/min global, 1000 req/min per tenant)
- [ ] CSRF protection enabled on forms
- [ ] Session cookies secured (HttpOnly, Secure, SameSite)
- [ ] SQL injection protection verified
- [ ] XSS protection enabled (Askama escaping)
- [ ] File upload validation active
- [ ] Admin routes protected

### Infrastructure Security
- [ ] SSH password auth disabled
- [ ] Firewall rules active (UFW)
- [ ] Database not exposed externally
- [ ] Redis not exposed externally
- [ ] Secrets in environment variables (not committed)
- [ ] `.env` file permissions 600

### Audit & Compliance
- [ ] Audit logging enabled
- [ ] GDPR data export implemented
- [ ] Data deletion procedures ready
- [ ] Terms of Service published
- [ ] Privacy Policy published

---

## 📊 Monitoring

### Netdata Integration
- [ ] Netdata dashboard accessible
- [ ] Custom Lillpepe charts configured
- [ ] Alert thresholds set
- [ ] Email/webhook alerts configured
- [ ] Health check alarms active

### Application Monitoring
- [ ] Job queue stats tracked
- [ ] Session counts monitored
- [ ] Failed jobs alerted
- [ ] API response times tracked
- [ ] Error rates monitored

### System Monitoring
- [ ] CPU usage < 80%
- [ ] Memory usage < 80%
- [ ] Disk space < 80%
- [ ] Network traffic normal
- [ ] Process count normal

### Logging
- [ ] Application logs: `journalctl -u lillpepe -f`
- [ ] Nginx access logs: `/var/log/nginx/lillpepe.access.log`
- [ ] Nginx error logs: `/var/log/nginx/lillpepe.error.log`
- [ ] Log rotation configured
- [ ] Log retention policy set (90 days)

---

## 💾 Backup

### Database Backups
- [ ] Daily automated backups (2 AM)
- [ ] Backup script tested: `healthcheck backup`
- [ ] Backups stored: `/var/backups/lillpepe`
- [ ] Retention: 90 days
- [ ] Restore procedure documented and tested

### File Backups
- [ ] Static files backed up
- [ ] Uploaded media backed up (`/opt/lillpepe/storage/uploads`)
- [ ] Configuration backed up (`.env`, nginx config)
- [ ] Backup verification automated

### Disaster Recovery
- [ ] Recovery procedure documented
- [ ] Restore tested on staging environment
- [ ] RTO defined: < 4 hours
- [ ] RPO defined: < 24 hours

---

## 🧪 Testing

### Load Testing
- [ ] 100 concurrent users tested
- [ ] 1000 requests/second tested
- [ ] Database connection pool verified
- [ ] Memory leaks checked
- [ ] Response times < 2 seconds

### Integration Testing
- [ ] User registration flow
- [ ] Login/logout flow
- [ ] Tenant onboarding flow (6 steps)
- [ ] Product CRUD operations
- [ ] File upload/delete
- [ ] Payment webhook processing

### Failure Testing
- [ ] Database down scenario
- [ ] Redis down scenario
- [ ] Disk full scenario
- [ ] OOM scenario
- [ ] Network partition scenario

### Security Testing
- [ ] SQL injection attempts blocked
- [ ] XSS attempts blocked
- [ ] CSRF attacks blocked
- [ ] Rate limiting enforced
- [ ] Unauthorized access denied

---

## 📧 Email System

### SMTP Configuration
- [ ] SendGrid/SMTP credentials configured
- [ ] From email verified
- [ ] Test email sent successfully
- [ ] Email templates rendering correctly
- [ ] Unsubscribe links working

### Email Templates
- [ ] Welcome email tested
- [ ] Password reset tested
- [ ] Invoice email tested
- [ ] Subscription created tested
- [ ] Payment failed tested
- [ ] Tenant provisioned tested

---

## 🎯 Business Logic

### Tenant Onboarding
- [ ] Step 1: Email verification working
- [ ] Step 2: Plan selection working
- [ ] Step 3: Payment setup working
- [ ] Step 4: Domain selection working
- [ ] Step 5: Tenant provisioning working
- [ ] Step 6: Initial setup working

### Job Queue
- [ ] Workers processing jobs
- [ ] Failed jobs retrying (max 3 times)
- [ ] Priority queue functioning
- [ ] Scheduled jobs executing
- [ ] Job stats dashboard accessible

### Session Management
- [ ] Login creating sessions
- [ ] Session validation working
- [ ] Session refresh on activity
- [ ] Logout destroying sessions
- [ ] Expired sessions cleaned up

### Audit Logging
- [ ] All actions logged
- [ ] Query filters working
- [ ] Export to JSON/CSV working
- [ ] Retention policy enforced
- [ ] Admin dashboard showing logs

---

## 📱 Admin Dashboard

### Pages Accessible
- [ ] Dashboard overview
- [ ] Tenants list
- [ ] Tenant detail
- [ ] Jobs monitoring
- [ ] Audit logs viewer

### Operations Working
- [ ] Suspend tenant
- [ ] Activate tenant
- [ ] Delete tenant (queued)
- [ ] Retry failed job
- [ ] Export audit logs

---

## 🚦 Go-Live

### Pre-Launch
- [ ] All checklist items complete
- [ ] Staging environment tested end-to-end
- [ ] Load test passed (1000 concurrent users)
- [ ] Security audit passed
- [ ] Backup/restore tested
- [ ] Monitoring dashboards configured

### Launch Day
- [ ] DNS switched to production
- [ ] SSL certificate verified
- [ ] First user registration tested
- [ ] First tenant onboarding completed
- [ ] Payment processing verified
- [ ] Email notifications working

### Post-Launch Monitoring (First 24 Hours)
- [ ] Monitor error rates
- [ ] Monitor response times
- [ ] Monitor job queue
- [ ] Monitor database performance
- [ ] Monitor disk space
- [ ] Check logs for errors

---

## 📞 Support

### Documentation
- [ ] User guide published
- [ ] Admin guide published
- [ ] API documentation published
- [ ] Troubleshooting guide published
- [ ] FAQ published

### Contact
- [ ] Support email configured: `support@lillpepe.com`
- [ ] Response time SLA defined: < 24 hours
- [ ] Escalation procedure documented
- [ ] Status page setup (optional)

---

## ✅ Final Sign-Off

- [ ] All critical checklist items complete
- [ ] No blockers remaining
- [ ] Team agrees ready for production
- [ ] Rollback plan documented
- [ ] On-call rotation scheduled

---

## 🎉 SHIP IT!

**Once all items are checked, you're ready to deploy to production.**

**Launch command:**
```bash
./tools/deploy.fish
```

**Monitor:**
```bash
journalctl -u lillpepe -f
```

**Good luck! 🚀**